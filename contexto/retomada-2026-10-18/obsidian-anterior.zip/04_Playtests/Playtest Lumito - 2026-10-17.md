# Lumito: passeio, visão, pânico e cansaço

Entrega de 17/10/2026 — pronta para teste manual, ainda não aprovada.

## Comportamento implementado

- Passeia perto do local de nascimento, com pequenas pausas e passos animados.
- Detecta jogadores vivos num cone frontal de 110°, até 28 studs, com linha de visão. Não deve detectar pelas costas ou através de obstáculos.
- Corre a 14 studs/s durante 5 segundos após detectar alguém; guarda a última posição vista quando perde contato visual.
- Fica cansado durante 7 segundos, caminhando a 1,8 studs/s mesmo que continue vendo alguém. Passeio normal: 3,5 studs/s. Após recuperar, pode se assustar novamente.
- Desvia localmente de obstáculos, fica dentro do gramado da ilha, acompanha pequenas diferenças de altura e mantém separação de jogadores/Lumitos. Quando não há passagem segura, para e procura outra direção; não teleporta nem atravessa o bloqueio deliberadamente.
- Nome ganha `!` no pânico e `…` no cansaço. Movimento do corpo/pés diferencia passeio e corrida.
- Para durante a disputa do laço. Se escapar, entra no período cansado. Captura concluída remove o agente; respawn cria um novo. Criaturas instaladas na base não recebem IA.
- Comum e dourado usam o mesmo perfil nesta primeira fatia, respeitando o tamanho do modelo. Não foram criadas novas espécies, mutações ou upgrades.

Parâmetros: `server/CreatureProfiles.luau`. Comportamento: `server/LumitoBehavior.luau`. Registro/ciclo de vida: `server/CreatureBehaviorService.luau`. Novas espécies poderão selecionar outro módulo no registro, sem misturar IA com economia/captura.

## Checklist para o desenvolvedor

1. **Passeio:** entrar em Play, observar de longe por alguns segundos. Os Lumitos devem alternar passos lentos e pausas, sem afundar, flutuar ou se desmontar.
2. **Visão frontal:** aproximar-se por trás e depois passar à frente. Confirmar que o pânico começa à frente, acompanhado de `!`, e que não exige equipar o laço.
3. **Visão bloqueada:** esconder-se atrás de uma árvore/rocha que realmente cubra a linha entre vocês. Sair do abrigo à frente do Lumito deve provocar a fuga; permanecer totalmente oculto não deve provocar detecção inicial.
4. **Cansaço:** perseguir após o susto. Após cerca de 5 s, ele deve desacelerar claramente e mostrar `…` por cerca de 7 s. A presença contínua do jogador não deve reiniciar a corrida durante esse período.
5. **Navegação:** conduzi-lo em direção a árvores, rochas, outros Lumitos e bordas. Conferir desvios, ausência de atravessamento/quedas e se consegue sair de cantos sem oscilar indefinidamente. Quando completamente cercado, parar é aceitável.
6. **Captura:** tentar laçar enquanto corre e enquanto está cansado. O alvo deve parar ao iniciar o minigame. Cancelar/desequipar deve liberá-lo cansado; vencer deve removê-lo e gerar um novo no spawn após o intervalo existente.
7. **Base e variante:** depositar um capturado e conferir que ele permanece na base. Quando aparecer um dourado, conferir especialmente pés, tamanho e passagem perto de obstáculos.
8. **Interface:** abrir bolsa e os três recursos. Não deve existir botão de som; título e fechar devem continuar legíveis. Os efeitos sonoros permanecem ativos.

Se houver outra pessoa disponível, conferir posteriormente se ambos veem a mesma movimentação e se o Lumito reage aos dois, sem duplicar captura. Não é necessário executar tudo em múltiplos dispositivos agora.

Ao reportar um problema: indicar passo acima, comum/dourado, local da ilha e resultado observado. Se aparecer erro no Output, copiar a mensagem completa.

## Verificação realizada pelo assistente

Somente comparação de fontes antes da edição, revisão do código/diff, `git diff --check`, sincronização com igualdade de fontes confirmada e carregamento dos três novos ModuleScripts em Edit (todos retornaram tabelas, sem erro). Nenhuma nova sessão de Play, emulação, benchmark ou bateria de testes foi executada. O Play que já estava aberto foi parado para editar.

A navegação é local, apropriada à ilha aberta atual; não é um planejador de rotas para labirintos/terrenos complexos. Comportamento, colisões percebidas e balanceamento aguardam os testes acima. Consulta de API: [WorldRoot — Blockcast e consultas de volume](https://create.roblox.com/docs/reference/engine/classes/WorldRoot). As checagens de varredura e ocupação são complementares.

Preferência permanente: testes extensivos ficam com o desenvolvedor, conforme `AGENTS.md` e as notas de processo no Obsidian. Ajustes posteriores devem continuar usando revisão leve e checklist manual, salvo pedido explícito diferente.
