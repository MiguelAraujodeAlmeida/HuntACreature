---
tipo: entrega
status: aguardando_playtest
atualizado: 2026-10-18
---
# Loja, upgrades e Index — 18/10/2026

O desenvolvedor aprovou [[Pesquisa Comparativa de Sistemas - 2026-10-18]] como base para as mudanças e reforçou identidade própria, personalização e expansão futura. Esta implementação revisa os três sistemas; sugestões de conteúdo extra não foram adicionadas automaticamente.

## Entregue no Studio Edit

- Index com botão próprio no HUD, atalho I, filtro por raridade, paginação, ficha de espécie e distinção entre descoberta permanente e posse atual.
- Melhorias individuais: Base no totem/painel da base; Bolsa dentro da bolsa; Treino e Eficiência por Q/Y junto ao manequim, com compras separadas e prévia do resultado; Velocidade com acesso próprio no HUD/atalho V.
- Loja com catálogo completo dos itens comercializáveis, categorias, informações de efeito/preço/recarga, itens sem estoque, cota pessoal e equipamento já adquirido. Cada item define sua chance e faixa de quantidade. Isca tem presença recorrente; chances e quantidades são provisórias.
- Definições e regras concentradas em GameplayConfig. Apresentação separada em ShopPage, UpgradePage e IndexPage. Listas de ordem não impedem inclusão de novos IDs. Capacidade visual da base acompanha os níveis configurados.
- Perfis anteriores preservados; catálogo versão 2 mantém compras da mesma janela temporal. Não foram trocados IDs de criaturas, schema ou DataStore.

Novas espécies jogáveis ainda precisam de modelo/geração/comportamento, e ferramentas novas precisam de efeito/controles. Catálogo configurável não substitui a implementação de mecânicas novas. A fábrica de Lumito não foi reescrita nesta entrega.

## Verificado

34 fontes comparados antes da edição. 11 fontes novos/alterados compilados; dois ajustes finais de apresentação/posição recompilados. Nove verificações pequenas em tabelas isoladas passaram, cobrindo compra independente, prévia, estoque/cotas e compatibilidade de perfil.

O desenvolvedor pediu confirmação após possível desconexão do MCP. A conexão foi restabelecida com o mesmo lugar, placeId 102310424634629. Os 34 fontes no Studio ainda eram os anteriores; os novos estavam preservados localmente. Aplicados oito arquivos existentes e três módulos novos. **37 fontes locais/Studio conferidos sem diferenças.**

Nenhum Play, simulação de jogadores, DataStore real ou teste auditivo executado. Nenhuma publicação ou nova cópia completa `.rbxl` confirmada. Backup dos fontes anteriores em `contexto/antes-loja-upgrades-index-2026-10-18/studio`.

## Teste manual

1. Abrir os novos acessos em desktop/tela pequena; conferir rolagem, textos e botões.
2. Comprar cada melhoria separadamente e conferir custo, efeito exclusivo e ganho real do treino. Testar saldo insuficiente e proximidade da própria base/manequim.
3. Conferir itens sem estoque, consumir/comprar, esgotar cota e observar reposição; laço inicial aparece adquirido.
4. Comparar loja entre jogadores/servidores e reconectar: mesmas ofertas, cotas independentes e progresso preservado. Conferir compra na virada.
5. Capturar, instalar/trocar e vender: Index mantém descoberta e atualiza posse. Conferir que caça e ferramentas continuam funcionando.

Guia técnico, configuração e limitações: [LOJA_UPGRADES_INDEX.md](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/LOJA_UPGRADES_INDEX.md>).

Relacionados: [[Estado Atual]], [[Progressao]], [[Jogabilidade]], [[Backlog]]. Implementação não significa experiência aprovada.
