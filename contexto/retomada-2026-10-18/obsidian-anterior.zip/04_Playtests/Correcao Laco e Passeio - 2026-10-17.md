# Correção do laço e passeio variável — 17/10/2026

## Diagnóstico e alteração

O servidor calculava `projectile.distance = resolved.distance`: a distância até a superfície vista no instante do lançamento. Quando o Lumito se afastava, o projétil chegava à posição antiga e retornava, mesmo com alcance restante. O acerto também usava somente uma linha central contra as peças na posição do frame atual, sem largura do anel e sem considerar a travessia da criatura entre atualizações. A IA começou a expor essas limitações do lançamento originalmente feito para alvos estáticos.

O ponto mirado continua determinando a direção reta. Agora o voo usa o alcance permitido pela carga e verifica contatos durante o percurso. `LassoCollision` calcula contato contínuo relativo entre o projétil e o corpo móvel, incluindo sobreposição inicial. A área central de captura usa o tamanho do corpo e o raio de 1,1 studs do anel; os detalhes pequenos/animados do modelo não comandam a captura. É uma aproximação volumétrica, não colisão exata de cada pé/orelha.

Obstáculos usam varredura esférica do mesmo raio; o primeiro bloqueio limita o contato com criaturas. Há também verificação de linha de visão entre contato e corpo, para não capturar através de cobertura. Não há perseguição automática do alvo, alcance infinito nem compensação completa de latência. Validações de bolsa, exclusividade e início do minigame continuam no servidor.

## Passeio normal

- Caminhadas de 1,2–4,5 s, com pequena variação de velocidade por trecho.
- Pausas de 1–3 s; 25% delas podem durar 3,5–6 s.
- Pode interromper o trajeto antes de chegar ao destino; ao retomar, tem 45% de chance de conservar um destino ainda válido.
- Visão continua ativa enquanto parado. Pânico, cansaço e captura continuam tendo prioridade sobre o passeio.
- Modelo e animação provisória não foram polidos nesta entrega, conforme pedido.

## Verificação leve executada

Fontes locais comparados com Studio antes da edição; igualdade confirmada após sincronização; diff revisado; `git diff --check`; módulos alterados carregados em Edit. Nove regressões matemáticas em `tests/LassoCollision.spec.luau` passaram, sem iniciar Play, emular dispositivos ou criar cenário de teste. Incluem reprodução do término precoce antigo, alvo afastado ainda no alcance, cruzamento entre frames, início sobreposto, contato lateral, erro verdadeiro, limite de segmento e segmento degenerado.

Essas verificações não comprovam a experiência de captura em jogo, latência, cobertura ou ritmo de passeio. A confirmação é manual abaixo.

## Teste manual solicitado

1. Com bolsa livre, acertar o corpo de um Lumito parado, andando e correndo. Conferir se o minigame inicia uma única vez e o alvo para.
2. Lançar enquanto ele se afasta na direção do tiro: o laço não deve recolher no ponto onde a criatura estava antes, se ainda houver alcance.
3. Lançar para interceptar um Lumito cruzando de lado. Comparar contato pelo centro, perto da lateral do corpo e um erro claramente afastado.
4. Tentar atingir atrás de árvore/rocha e além do alcance. Não deve atravessar cobertura nem continuar indefinidamente. Verificar também erro livre no céu/chão e recolhimento.
5. Observar de longe por aproximadamente um minuto: deve haver caminhada, pausas curtas, algumas mais longas e retomadas variadas. Aproximar-se pela frente durante uma pausa deve provocar pânico.

Se falhar, informar se estava comum/dourado, parado/correndo/cansado, se a bolsa estava cheia e se havia obstáculo próximo. Polimento visual da locomoção segue adiado.
