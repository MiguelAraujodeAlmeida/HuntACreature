---
tipo: entrega
status: aguardando_playtest
atualizado: 2026-10-18
---
# Consolidação UX e ferramentas — 18/10/2026

O desenvolvedor confirmou: **ainda não testou a primeira base**, mas autorizou a próxima entrega para testar ambas juntas. Continuação de [[Base Mecanica - 2026-10-17]], dentro de [[Plano da Base de Gameplay]]. Não há aprovação de diversão, áudio ou persistência real.

## Aplicado ao Studio Edit

- Prévia de isca/armadilha verde/vermelha com motivo escrito; cliente e servidor compartilham limites de posicionamento. Validação e consumo continuam no servidor.
- Seleção marcada, quantidade durante recarga e motivo de indisponibilidade. Poção continua exclusiva da captura.
- Bolsa/base/loja não recriam cartões por renda/treino. Saldo e disponibilidade atualizam no lugar; reconstruções necessárias tentam recuperar foco e rolagem.
- Renda/treino não invalidam a revisão de uma ação em andamento. Continuam sendo incluídos no perfil salvo; ações/capturas continuam avançando a revisão.
- Compra indica ouro faltante, cota esgotada, limite de unidades ou item já adquirido. Troca mantém a escolha quando recusada e a explica no topo da Base. Index mostra descobertas/total.

Sem ajuste de preços, ganhos, durações, catálogo ou áudio. Números continuam provisórios.

## Verificado pelo assistente

Cinco fontes existentes comparados antes de editar; dez arquivos pertinentes compilados; doze verificações pequenas de conteúdo dos painéis, revisão e posicionamento passaram. Dados em memória e sólidos temporários isolados, removidos ao final. Oito fontes sincronizados e conferidos no Studio Edit, incluindo três módulos novos. Nenhum Play, teste de DataStore real ou avaliação visual/auditiva.

Fontes/guia: `C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/CONSOLIDACAO_UX_FERRAMENTAS.md`. Cópia anterior: `contexto/antes-consolidacao-2026-10-18` no projeto.

## Roteiro conjunto — execução humana

1. Capturar → instalar → capturar/vender outro; conferir contato, IA, disputa, som, ouro e index. Trocar com bolsa/base cheias.
2. Deixar Bolsa/Loja abertos durante renda; rolar/selecionar/confirmar e verificar estabilidade e atualização do saldo. Conferir tela pequena e controle.
3. Posicionar isca/armadilha em chão livre, longe, com obstáculo, fora da área e perto de outra ferramenta. Conferir prévia/motivo e consumo só quando válido; cancelar seleção.
4. Conferir quantidade/recarga, falta de unidades e poção dentro/fora da captura. Treino, painéis e respawn não deixam prévia presa.
5. Comprar ferramenta e melhorias; verificar saldo insuficiente/cota e botão liberando após renda; conferir benefício do treino e das cinco categorias.
6. Reconectar com salvamento real; conferir exemplares, variações, saldo, força, upgrades, index, itens e cota. Comparar ofertas entre servidores e cotas individuais.

Configuração de persistência e checklist completo em [[Base Mecanica - 2026-10-17]]. Registrar primeiro bloqueio reproduzível, com ação/observado/esperado e dispositivo quando relevante. Não marcar aprovado antes do parecer humano.
