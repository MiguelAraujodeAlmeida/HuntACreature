# HUD responsivo e áudio — 17/10/2026

Estado: aplicado ao Studio e pronto para playtest do desenvolvedor. Não equivale a aprovação da experiência.

## Entrega

- `HUDLayout` calcula medidas pela área segura disponível, com reorganização dos recursos e limites para painéis. Os controles interativos não são encolhidos por uma escala global.
- Bolsa, informações, carga, disputa e slot respondem à alteração da janela. Cartões de recursos inteiros são clicáveis; o botão visual de mais preserva o acabamento verde.
- Reserva lateral para controles de movimento/toque no painel de captura. Orientação do jogo preservada: LandscapeSensor.
- `AudioConfig` centraliza assets, volume, pitch e intervalo mínimo. `AudioFeedback` pré-carrega cinco assets, limita a oito vozes, limpa instâncias e interrompe a carga cancelada.
- Sons de interface, carga completa, lançamento, retorno, impacto, progresso, renda e vitória. Variante dourada recebe uma sequência adicional. Controle de som dentro da bolsa/painel de informações; preferência apenas nesta sessão.
- Texturas e regras de economia/captura não foram alteradas.

## Verificações executadas

Medidas abaixo são pixels de UI reportados pelo Studio, não a resolução física anunciada do aparelho.

| Perfil | Viewport | Área segura | Evidência |
|---|---|---|---|
| Janela desktop | 906,4 × 584 | 906,4 × 526 | Abrir/fechar bolsa, alternar som e abrir detalhes de ouro com entrada real; inspeção visual |
| Galaxy A06 horizontal | 705 × 338 | 705 × 280 | Bolsa aberta por clique, textos/controles visíveis; disputa inspecionada na etapa anterior |
| iPhone 17 Pro horizontal | 750 × 381 | 750 × 323 | HUD e disputa inspecionados na etapa anterior à interrupção de contexto |
| iPad Pro M5 13 horizontal | 1375 × 1032 | 1375 × 974 | Redimensionamento ao vivo com bolsa aberta, sem corte do painel |
| Desktop HD 1080 | 1919 × 1079 | 1919 × 1021 | Recursos empilhados, captura acima do slot; inspeção visual |

- Capturas visuais do minigame usaram eventos controlados `CaptureStart`/`CaptureState`, sem recompensas nem alteração de inventário. Não representam uma caça completa vencida.
- Teste de lançamento real: equipar Tool, segurar entrada até 100%, soltar; painel de carga ocultado; sons `Throw` e `Return` observados tocando; efeitos de voo retornaram a zero após recolhimento.
- Mudo: `SoundGroup.Volume == 0`, legenda `Som: mudo`; reativação voltou a aproximadamente 0,7.
- Cinco assets com `IsLoaded = true` e duração positiva em Play. Não houve avaliação auditiva subjetiva pelo assistente.
- Console consultado: avisos internos de FoundationProvider/CorePackages; nenhum erro de script HAC observado nessa saída.
- `git diff --check` passou. Três ajustes finais foram sincronizados e executados no Studio após comparar os fontes.
- Cliques do MCP exigiram foco da janela; no emulador A06 houve deslocamento de coordenadas da ferramenta, compensado a partir da posição do mouse observada. Isso é uma limitação da automação; toque físico continua pendente.

## Limites e próximo playtest

Testar em celular físico: movimentar e lançar simultaneamente, manter o alvo visível, ler a disputa sem esforço e abrir/fechar a bolsa. Ouvir em fone e alto-falante: clareza do impacto, contraste entre comum/dourado e fadiga após cinco minutos. Ajustar a paleta em `AudioConfig` após esse parecer.

Não foram validados multiplayer, controle físico, telas arbitrariamente menores, orientação retrato, latência de rede ou disponibilidade dos assets em uma sessão publicada. O jogo continua horizontal. Persistência do mute e controle separado de música/ambiente ficam para uma etapa posterior.

Encerramento: Play parado, simulação desativada, LandscapeSensor preservado. O controle nativo foi interrompido pelo usuário com Escape antes da cópia completa do lugar. Fontes estão no disco e no Studio; nenhum novo `.rbxl` nem publicação foi confirmado.
