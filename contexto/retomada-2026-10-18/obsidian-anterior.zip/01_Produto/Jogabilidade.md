---
tipo: escopo
status: planejado
atualizado: 2026-10-18
---
# Jogabilidade

## Direção confirmada

Movimentação agradável, combate dinâmico, progressão recompensadora e vontade de repetir a caça. Completar e polir o núcleo antes de ampliar conteúdo e sistemas complexos.

- Trocar uma criatura da mochila por uma instalada na base, fazendo ambas trocarem de lugar.
- Index de todas as criaturas.
- Melhorar a experiência geral, incluindo clareza de comandos, ritmo, feedback e recompensa.

## Ciclo que a base precisa completar

Encontrar → escolher abordagem → capturar → identificar o exemplar → guardar → instalar, trocar ou vender → investir ouro/treinar → caçar novamente com benefício perceptível.

A decisão entre renda contínua, ouro imediato e descoberta para coleção deve dar propósito à captura. Venda/troca/index/compras/persistência foram implementados em [[Base Mecanica - 2026-10-17]], mas o ciclo completo ainda aguarda playtest humano. A [[Auditoria da Base Mecanica - 2026-10-17]] registra a situação anterior à implementação.

## Troca bolsa/base

Selecionar dois indivíduos e mostrar a troca antes de executá-la. Operação autoritativa e conjunta, válida mesmo com bolsa e base cheias. Preservar IDs, tamanho, mutações e descobertas; atualizar renda, posição visual e cartões. Não implementar como retirar primeiro e descobrir depois que falta espaço. Venda e troca concorrentes do mesmo ID só podem produzir um resultado válido.

## Index

Primeira versão: catálogo, progresso descoberto/total e ficha simples do que já foi capturado. Descobertas persistem após venda. Definições de espécie alimentam o catálogo; inventário atual não é o catálogo. Informações de variantes e ocultação de raridades secretas podem ser refinadas depois. Ver [[Criaturas]].

**Decisão explícita de 18/10 implementada:** Index agora tem botão próprio no HUD e atalho I, abrindo diretamente sua tela com filtro de raridade e paginação. Ficha distingue descoberta permanente e posse atual. Registro separado de mutações, recorde de tamanho e recompensas por descoberta permanecem candidatos posteriores. Entrega em [[Loja Upgrades e Index - 2026-10-18]], aguardando playtest; referência em [[Pesquisa Comparativa de Sistemas - 2026-10-18]].

## Melhorias candidatas, por prioridade

1. **Próximo objetivo claro:** mostrar benefício e custo da próxima melhoria relevante sem poluir o HUD.
2. **Captura comum ágil:** pouco tempo sem decisão; erro legível e nova tentativa rápida.
3. **Escolha antes do lançamento:** aproximar silenciosamente, aguardar cansaço ou gastar uma ferramenta; começar com o que a IA já permite.
4. **Recompensa informativa:** descoberta nova recebe uma celebração curta distinta; duplicata útil mostra valor/renda, sem abrir várias telas.
5. **Movimentação:** revisar resposta, câmera e acesso às ações durante a caça. Só experimentar sprint/dash se o deslocamento básico ainda precisar deles; não estão aprovados como novos sistemas.
6. **Variação leve:** pequenas diferenças no ritmo da disputa por perfil, desde que o sinal visual antecipe o desafio.

São propostas, não tarefas aprovadas automaticamente. Evitar “mais divertido” virar uma lista de efeitos: cada entrega deve melhorar uma escolha ou reduzir uma frustração observável.

## HUD e som

Manter a direção glossy e adaptar layout ao dispositivo. Capacidade/itens devem vir dos dados, com seleção clara e ações contextuais. Uso de consumível não deve disputar o mesmo botão com o comando principal de captura. Som distingue lançamento, acerto, erro, avanço e recompensa; qualidade auditiva depende do parecer do desenvolvedor. Configurações de áudio ficam na futura aba de configurações, sem mute em cada painel.

## Aceite humano

O desenvolvedor percorre um ciclo completo sem perder item, sem bloqueio de controles e sem precisar de explicação para a próxima ação. Avalia clareza, vontade de repetir e momentos de espera/frustração. Testa toque e desktop na entrega que muda controles ou layout. Resultado funcional não equivale a diversão aprovada.
