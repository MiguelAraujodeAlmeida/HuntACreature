---
tipo: produto
status: provisoria
atualizado: 2026-10-17
---

# Direção visual e UX

## Feedback vinculante

Correção posterior de 17/10: remover o botão de som de bolsa/recursos. Configurações de áudio devem ficar em uma futura aba de configurações, ainda não implementada. Não repetir esse controle nos painéis do jogo.

Atualização de 17/10: o requisito mais recente é HUD responsivo, UX de caça mais divertida e som satisfatório. Texturas atuais são provisórias e seu refinamento foi adiado. A referência posterior de botões glossy e cartões escuros com bordas ciano/dourado supera a leitura antiga de remover todas as caixas. HUD v4 adaptável e primeira paleta sonora aguardam playtest; ver [[Estado Atual]] e [[Propostas de UX]].

O desenvolvedor rejeitou a primeira UI por parecer genérica, excessivamente encaixotada e cheia de instruções. Pediu ícones originais, fonte mais agradável, recursos sem caixas coloridas, HUD que se explique por si e tela livre durante a caça. Também rejeitou o painel grande do primeiro minigame. O protótipo v2 tentou resolver isso, mas **ainda não foi aprovado**. Capturas preservadas em [[Referencias Visuais]].

## Regras provisórias para o protótipo

- **Referência mais recente (16/10/2026):** botões glossy com volume, bordas luminosas ciano/dourado, ícones grandes, legenda branca com contorno e efeitos ao interagir. Aplicado nos quatro controles atuais; em validação. Parâmetros e comportamento compartilhados para facilitar futuras mudanças. Nenhuma referência visual constitui aprovação permanente.

- Um conjunto consistente de fontes, ícones, contornos, materiais e escala. Os valores técnicos atuais ficam em `studio/shared/VisualStyle.luau` e `studio/STYLE_GUIDE.md`.
- Silhueta própria: corda, laço, expedição, criaturas e mutações. Cor e efeitos sinalizam ação, recompensa e raridade.
- HUD em bordas e contexto; barra de carga longa e central durante o lançamento; informações relevantes durante a disputa, sem tutorial permanente.
- Interface legível em PC e celular horizontal, considerando áreas seguras, toque e o alvo no mundo.
- Cenário lúdico/modular e criaturas expressivas; evitar realismo isolado e modelos que não compartilhem linguagem visual.

## Validação antes de escalar a produção

Fazer uma amostra aprovada: uma tela de HUD, um trecho de hub/ilha e uma criatura com variante. Capturar imagens em PC e celular e comparar legibilidade, personalidade e energia. Só depois usar como padrão para muitas telas ou modelos. Uma mudança de direção visual deve atualizar esta nota e o guia técnico.
