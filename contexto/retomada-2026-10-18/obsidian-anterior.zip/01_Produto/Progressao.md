---
tipo: escopo
status: revisao_implementada_aguardando_playtest
atualizado: 2026-10-18
---
# Progressão

Primeira implementação autorizada em [[Plano da Base de Gameplay]], registrada em [[Base Mecanica - 2026-10-17]]. Gameplay e persistência real aguardam teste humano.

## Escopo e implementação

| Categoria | Benefício inicial | Custos dos três upgrades |
|---|---|---|
| Base | Capacidade 3 → 4 → 5 → 6 | 40 / 100 / 220 ouro |
| Bolsa | Capacidade 3 → 4 → 5 → 6 | 25 / 70 / 160 ouro |
| Treino | Ganho básico 1 → 2 → 3 → 4 força por intervalo | 30 / 90 / 180 ouro |
| Multiplicador | 1 → 1,25 → 1,5 → 2 vezes o ganho | 50 / 140 / 300 ouro |
| Velocidade | 16 → 18 → 20 → 22 studs/s | 35 / 100 / 240 ouro |

Treino automático no manequim, conforme [[ADR-002 - Treino no manequim]]. Ganho a cada 2 s = ganho básico × multiplicador. Jogador imóvel no posto, saída explícita e restauração da velocidade. Força tem curva de benefício decrescente na captura; XP continua acumulado, sem novo sistema de níveis.

Todos os números são provisórios, centralizados em GameplayConfig. Outros upgrades ficam para expansão.

### Feedback e pesquisa — 18/10

O desenvolvedor não aprovou a primeira experiência de upgrades e reafirmou que quer melhorar cada categoria individualmente. A pesquisa foi aprovada para implementação: [[Loja Upgrades e Index - 2026-10-18]] aplicada em Edit. Base pelo totem/painel Base; bolsa dentro da bolsa; treino e eficiência por Q/Y no manequim, em compras separadas; velocidade com acesso próprio no HUD. Prévia mostra efeito atual/próximo e ganho final do treino. Proximidade é validada por grupo; bolsa/velocidade não exigem voltar à base. Parecer humano pendente.

## Venda e troca

Venda por ID da criatura na mochila ou na base, com valor exibido e confirmação contextual. Remoção e crédito de ouro são uma operação única. Venda na base atualiza renda, modelo e espaço. Troca bolsa/base mantém IDs/características e funciona com ambas cheias. Operações da base exigem proximidade da própria base. Ver [[Jogabilidade]].

## Loja global — decisão fechada

**Confirmado pelo desenvolvedor:** mesmas ofertas e mesma rotação para todos os servidores, com **cota individual por jogador**. Compras de outras pessoas não diminuem sua quantidade. Não há reserva coletiva global nesta versão.

Implementação revisada: janela de 5 minutos, catálogo completo dos itens comercializáveis e chance/faixa de quantidade por item, incluindo estado sem estoque. Isca é recorrente; armadilha/poção têm disponibilidade variável. O balcão fica no hub e exige proximidade. Laço inicial aparece adquirido, sem criar novo modelo/tipo. Sorteio por época, versão e ID comuns aos servidores, independente da ordem da tabela.

Cota fica no perfil persistente. Pedido de compra com rotação antiga é recusado e recebe a seleção atual. Saldo, quantidade, propriedade e limite de itens são validados antes de debitar/conceder.

O desenvolvedor não aprovou a experiência inicial da loja. Após a pesquisa de Grow a Garden, a revisão foi autorizada e aplicada em [[Loja Upgrades e Index - 2026-10-18]]. Catálogo versão 2 preserva compras já feitas na mesma janela, sem devolver a cota pela mudança de versão. Ainda não há aprovação de UX/economia.

## Persistência

Perfil versionado guarda ouro, XP, força, criaturas/localização, ferramentas, upgrades, descobertas e cotas. Usa bloqueio de sessão, autosave e salvamento na saída. Studio e produção têm armazenamentos separados. Versões desconhecidas e falhas de leitura são recusadas, sem sobrescrever perfil com estado vazio.

Verificações anteriores com armazenamento simulado passaram. Após o bloqueio por APIs do Studio, o desenvolvedor confirmou que o jogo voltou a funcionar. Reconexão com preservação do progresso continua sem confirmação específica. A configuração de APIs não foi alterada pelo assistente. Modo temporário explícito não salva e não deve ser usado para validar persistência.

## Aceite manual

Vender de cada origem; repetir acionamento; trocar com ambas cheias; comprar cada upgrade e observar benefício; conferir treino/saída/respawn; comparar rotação em dois servidores; testar compra na virada, saldo insuficiente e cota esgotada; reconectar e conferir progresso/cotas.

Não houve aprovação da economia ou da duração das metas. Referência técnica: [dados de jogador e sessão — Roblox](https://create.roblox.com/docs/cloud-services/data-stores/player-data-purchasing).
