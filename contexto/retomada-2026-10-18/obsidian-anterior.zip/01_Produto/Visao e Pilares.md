---
tipo: produto
status: direcao
atualizado: 2026-10-17
---

# Visão e pilares

## Promessa ao jogador

Caçar criaturas com um laço que responde à mira e à habilidade, construir uma coleção interessante, exibi-la na base e sentir o crescimento do poder a cada sessão. O jogo é multiplayer, acessível no PC e no celular e fácil de entender sem textos persistentes na tela.

## Loop principal

Explorar → escolher a criatura → mirar/carregar/lançar o laço → disputar a captura → levar à base → gerar recursos → melhorar treino/equipamento/base → explorar desafios maiores. Ver [[Loop e Sistemas]].

## Pilares de decisão

1. **Caça com autoria:** o jogador escolhe onde lançar. Distância e carga de cada laço precisam ser legíveis e consistentes.
2. **Criaturas com vida e variedade:** espécies e modificadores mudam a aparência, o valor e o desafio. O mundo não pode parecer uma vitrine estática.
3. **Progresso sentido:** ações têm antecipação, impacto, confirmação e recompensa visual/sonora proporcionais ao valor; o crescimento também deve ter utilidade real.
4. **Leitura imediata:** HUD orienta por hierarquia, ícones e contexto; deixa a cena e o alvo visíveis.
5. **Mundo social e expansível:** hub/bases e ilha de caça têm papéis diferentes; sistemas devem receber criaturas, laços e eventos sem reescrever o núcleo.

## Inspirações e limites

*Grow a Garden*, *Steal a Brainrot* e *Steal an Egg* inspiram ritmo de progressão, clareza e energia. A identidade própria vem do laço, da caça, das mutações e dos eventos. A referência visual fornecida pelo desenvolvedor sugere materiais lúdicos e modulares, UI de alto contraste e recompensas vistosas; copiar o HUD ou criaturas de outro jogo não é objetivo.

## Escopo vigente — base antes de expansão

Escopo reafirmado em 17/10/2026: espécies, tamanhos, mutações e comportamentos próprios. Upgrades de **base, treino, bolsa, multiplicador da evolução de força e velocidade**, ferramentas, loja global, venda, troca bolsa/base e index integram a base autorizada. Primeira implementação entregue em [[Base Mecanica - 2026-10-17]], aguardando playtest humano. Lumito com variações é a amostra escolhida; segunda espécie fica para expansão.

Requisitos por domínio: [[Combate]], [[Progressao]], [[Criaturas]], [[Jogabilidade]], [[Interacao]]. Sequência: [[Plano da Base de Gameplay]]. As sete raridades seguem a ordem exata em Criaturas. Interferência durante captura ainda é hipótese, não autorização para roubo permanente.

## Ainda aberto

Balanceamento de preços/curvas, catálogo final, transporte físico, trocas entre jogadores, bosses, eventos, monetização e lançamento. Novo sistema de níveis XP não integra esta fase. Loja já tem decisão: mesmas ofertas globais com cotas individuais persistentes. Interferência permanece hipótese. Texturas, teletransporte e polimento de modelo/animação continuam adiados.
