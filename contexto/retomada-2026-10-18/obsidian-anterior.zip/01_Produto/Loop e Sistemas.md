---
tipo: produto
status: rascunho
atualizado: 2026-10-17
---

# Loop e sistemas

| Sistema | Intenção de experiência | Estado |
|---|---|---|
| Caça e laço | Mira exata, carga que altera alcance, acerto validado pelo servidor; diferenças claras entre laços | Protótipo v2 aguardando playtest |
| Disputa de captura | Tensão, controle suave, duração e dificuldade proporcionais; vitória satisfatória | Protótipo v2 aguardando playtest |
| Criaturas | Muitas espécies com tamanho, mutações e comportamento próprio | Lumito com passeio, cone de visão, fuga e cansaço implementado; aguardando teste manual |
| Base/coleção | Exibir conquistas e produzir ouro/XP; ter decisões de instalação e expansão | Instalação, venda, troca, index e capacidades implementados; aguardam teste |
| Treino | Avatar imobilizado no posto e animação automática laçando manequim; upgrades comprados com ouro | Manequim e melhorias implementados; aguardam teste |
| Hub e ilha | Hub social/bases; caça em região separada, com teletransporte claro | Ponte provisória |
| Economia | Ouro com gastos recorrentes e progressão motivadora, sem crescimento vazio | Venda, upgrades, loja e persistência implementados; valores provisórios |
| Eventos/multiplayer | Recombinar sistemas e criar momentos compartilhados | Ideias futuras, sem escopo fechado |

Upgrades de base, treino, bolsa, multiplicador da evolução de força e velocidade, venda, troca, index, ferramentas e loja receberam a primeira implementação do [[Plano da Base de Gameplay]]. Ver [[Base Mecanica - 2026-10-17]]. Comum e dourado compartilham a IA do Lumito. Aprovação do ciclo e persistência real ainda dependem de teste humano.

## Ciclo completo a validar

Encontrar → escolher abordagem/ferramenta → capturar → reconhecer espécie/variação → guardar → instalar, trocar ou vender → melhorar/treinar → voltar à caça. Index registra descobertas mesmo após a venda; persistência conserva o progresso entre sessões. A loja alimenta o preparo para caçar. Interferência social é hipótese posterior, não dependência do ciclo individual.

Consultar [[Combate]], [[Progressao]], [[Criaturas]], [[Jogabilidade]] e [[Interacao]] para requisitos, sugestões e critérios. [[Auditoria da Base Mecanica - 2026-10-17]] separa o que existe do que exige mudança estrutural.

## Experiência por captura

Encontrar → avaliar raridade/desafio → mirar → carregar com feedback claro → lançar → ver acerto/erro imediatamente → disputar → ganhar criatura/recurso com celebração proporcional. Cada etapa deve poder ser ajustada sem modificar HUD, física, regras e economia em um mesmo arquivo.

## Critério de diversão

Uma captura comum deve ser clara e ágil; uma rara deve aumentar tensão e recompensa. Evitar repetição longa sem nova escolha. Medir no playtest: entendimento sem explicação, sensação de controle, duração percebida, frustração por erro injusto e vontade de tentar outra criatura.
