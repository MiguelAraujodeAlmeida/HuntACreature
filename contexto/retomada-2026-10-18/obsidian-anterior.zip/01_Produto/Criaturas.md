---
tipo: escopo
status: pronto_para_playtest
atualizado: 2026-10-18
---
# Criaturas

## Escopo confirmado

Muitas espécies futuras, variações de tamanho, mutações, comportamento próprio, dificuldade, recompensas e raridade. Para concluir esta base, o desenvolvedor escolheu **Lumito com variações**, sem segunda espécie obrigatória.

## Raridades na ordem solicitada

1. Comum
2. Rara
3. Épica
4. Mítica
5. Lendária
6. Secreta
7. Divina

As sete categorias estão configuradas. O Lumito desta versão é Comum; Dourado é mutação, não uma raridade adicional. Chances/espécies das demais categorias serão definidas na expansão.

## Implementação atual

- Lumito com passeio, pausas variáveis, visão frontal/obstáculos, fuga e cansaço.
- Tamanhos sorteados: pequeno 0,85×, normal 1× e grande 1,2×, com pesos iniciais 25/55/20.
- Mutação Dourado: chance inicial 18%, altera apresentação, valor e dificuldade.
- Cada exemplar tem ID, espécie, raridade, tamanho, mutações e localização. Não se sorteiam características novamente ao instalar/trocar.
- Modelos e volumes acompanham escala; instalado usa escala de exibição 0,72 × tamanho do indivíduo.
- Perfil de comportamento separado; iscas e armadilhas interagem com a IA existente.
- Index registra descoberta por espécie e a preserva após venda.

Dados e operações foram verificados de forma leve. Modelos, navegação em tamanhos distintos e experiência de captura ainda dependem de Play humano. Ver [[Base Mecanica - 2026-10-17]].

## Maleabilidade

GameplayConfig concentra catálogo, categorias, tamanhos e mutações; CreatureFactory representa o indivíduo; inventário/base operam por ID. Nova IA pode exigir um módulo registrado, sem exigir refazer economia ou HUD. A navegação atual continua adequada ao gramado existente; não há promessa de suporte automático a voo, labirintos ou qualquer rig futuro.

## Aceite manual

Capturar variações, instalar, trocar com ambas cheias, vender outro indivíduo e reconectar mantendo IDs/características. Conferir contato do laço, bordas/obstáculos, visão, fuga/cansaço e resposta às ferramentas.

## Adiado

Segunda espécie, catálogo amplo, polimento de modelo/animação e texturas. Fichas detalhadas de variantes no index e regras de ocultação de espécies secretas não são obrigações desta primeira amostra.
