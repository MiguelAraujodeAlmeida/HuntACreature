---
tipo: estado
status: aguardando_playtest_da_revisao
atualizado: 2026-10-18
---
# Estado atual

## Revisão mais recente — loja, upgrades e Index

O desenvolvedor aprovou a pesquisa comparativa como base para implementar e reafirmou personalização/expansão futura. Entrega aplicada ao Studio Edit em [[Loja Upgrades e Index - 2026-10-18]]: upgrades com acessos individuais e prévia, loja por catálogo/estoque configurável e Index com botão próprio, filtro e paginação.

Após a possível desconexão do MCP, a conexão foi conferida no mesmo lugar. O Studio ainda tinha os 34 fontes anteriores; oito existentes foram atualizados e três módulos novos inseridos. **37 fontes locais/Studio agora iguais.** 11 fontes compilados (dois ajustes finais recompilados), nove verificações pequenas em tabelas isoladas passaram. Sem Play, publicação ou DataStore real nesta rodada.

Próxima ação: teste humano da revisão, conforme checklist da entrega. A fábrica/IA inicial do Lumito e os três efeitos de ferramentas foram preservados. Novos catálogos não substituem implementação de modelos e comportamentos novos.

## Entrega vigente — base mecânica implementada

O desenvolvedor autorizou executar o plano revisado completo. A primeira implementação está nos fontes locais e aplicada ao Studio **[Testing] Hunt a Creature**, placeId **102310424634629**, em Edit. **Nenhum Play iniciado pelo assistente.** Não há aprovação de experiência, áudio ou persistência real.

Guia de entrega e checklist: [[Base Mecanica - 2026-10-17]]. Sequência vigente: [[Plano da Base de Gameplay]]. Status: [[Backlog]].

Continuação aplicada em 18/10: [[Consolidacao UX e Ferramentas - 2026-10-18]]. Naquele momento, o desenvolvedor ainda não havia testado a primeira base e autorizou a rodada para testar as duas juntas. O feedback posterior está registrado abaixo.

## Implementado

- Laço a 100 studs/s, mantendo alcance/carga; colisão relativa anterior preservada. Ritmo da disputa ajustado, saída explícita, foco perdido solta comando e Space/A não salta durante captura.
- Som de carga sem disparos repetidos, mix de impacto/progresso/renda ajustado. Qualidade auditiva pendente.
- Lumito com tamanhos 0,85/1/1,2 e Dourado como mutação. ID e características preservados. Sete raridades configuradas na ordem solicitada; Lumito continua Comum.
- Perfil versionado e DataStore com posse de sessão, autosave e salvamento na saída. Studio usa armazenamento separado da produção.
- Bolsa/base por indivíduo: instalar, vender, trocar com ambas cheias; Index de descobertas permanentes agora com botão próprio, fichas, filtro e paginação.
- Isca, armadilha e poção durante disputa, com consumo/recarga e posicionamento validados.
- Manequim com laço automático e saída; três níveis compráveis por categoria. Acessos de base, bolsa, treino/eficiência e velocidade separados; prévia do benefício atual/próximo e ganho final de treino.
- Loja no hub: rotação global a cada cinco minutos, chance/quantidade por item, catálogo visível inclusive sem estoque, cota individual persistente e laço inicial marcado adquirido. Nenhum novo modelo de laço.
- Consolidação: prévia de posicionamento com motivo, seleção/quantidade/recarga claras, cartões estáveis durante renda, disponibilidade de compra, indicação da troca e contagem do index. Renda/treino continuam persistidos sem invalidar revisão de ações.

Preços, níveis, chances e durações são parâmetros iniciais de playtest, não economia aprovada.

## Verificado e pendente

Verificado: 24 fontes comparados antes da edição; 31 fontes carregados/compilados em Edit; 36 verificações pequenas de regras com armazenamento simulado; cinco verificações de apresentação em estrutura temporária; 31 fontes locais/Studio conferidos após sincronização.

Pendente humano: ciclo completo em Play, contato percebido/ritmo/IA, som, HUD/toque/controle, DataStore real e duas instâncias de servidor para loja/cotas. Não interpretar verificações simuladas como persistência real comprovada.

Rodada de consolidação: cinco fontes existentes comparados antes de editar; dez arquivos pertinentes compilados; doze verificações focadas passaram; oito fontes sincronizados/conferidos no Edit (três módulos novos, total de 34 fontes de runtime). Estruturas temporárias removidas. Nenhum Play ou acesso ao DataStore real.

O Studio precisa de acesso às APIs para teste persistente. Essa configuração não foi alterada. O atributo opcional HACStudioMemoryMode permite teste temporário explícito no Studio; não foi ativado e não é fallback automático. Falha de leitura não sobrescreve perfil com dados vazios.

### Primeiro bloqueio reportado no playtest — 18/10

O desenvolvedor iniciou o teste e foi desconectado após alguns segundos. Log do Studio confirmou `StudioAccessToApisNotAllowed` / erro 403 em `UpdateAsync`, armazenamento `HAC_Profiles_Studio_v1`: acesso do Studio aos serviços API desativado. A tela Segurança foi aberta e a opção foi conferida desligada. O teste desconectado foi encerrado; nenhum Play novo foi iniciado pelo assistente.

Orientação dada naquele atendimento: ativar **Permitir acesso do Studio aos serviços API** em Configurações da experiência → Segurança e salvar. A habilidade de controle do computador proíbe alterar permissões de segurança pela automação; a tela ficou aberta para o desenvolvedor. Nenhum código, dado salvo ou modo temporário foi alterado para contornar o bloqueio.

Feedback posterior: o desenvolvedor afirmou **“agora está funcional”**. O bloqueio de entrada é considerado resolvido pelo relato humano. Isso não confirma isoladamente salvamento/reconexão, cotas ou aprovação do ciclo completo. A persistência real ainda precisa do teste de sair/reentrar com progresso alterado.

### Pesquisa solicitada após o teste — 18/10

O desenvolvedor não gostou da experiência de loja e upgrades e pediu pesquisa comparativa antes de novas alterações. Confirmou upgrades individuais de base, treino, bolsa, multiplicador de evolução da força e velocidade, e **botão próprio de Index no HUD**. Confirmou também Steal a Brainrot como a terceira referência, junto de Grow a Garden e Steal an Egg.

Pesquisa concluída em [[Pesquisa Comparativa de Sistemas - 2026-10-18]]. A revisão dos fontes locais mostrou que os upgrades já possuem níveis separados; a apresentação conjunta e seus acessos precisam de revisão. A loja já tem rotação global/cotas pessoais, mas mostra apenas as ofertas selecionadas. O Index ainda está dentro do painel de coleção.

Esta rodada alterou apenas documentação. Não houve alteração de gameplay, sincronização com Studio ou execução de Play. Recomendações do relatório não são novos requisitos automaticamente aprovados.

## Decisões confirmadas e limites

- Loja usa **cota individual**, com mesmas ofertas globais; esgotamento coletivo descartado para esta base.
- Upgrades devem ser percebidos e comprados individualmente; Index deve ter botão próprio no HUD. A experiência atual de loja/upgrades não foi aprovada.
- Lumito com variações é a amostra suficiente; segunda espécie não é obrigação.
- Interferência social permanece hipótese. Texturas, teletransporte, polimento de modelo/animação e configurações de áudio seguem adiados.
- Sem novo sistema de níveis por XP, sprint/dash, eventos ou PvP.
- Preferência permanente: verificações leves pelo assistente; testes pesados só mediante pedido explícito. Sem agentes auxiliares sem pedido.

## Próximo passo

Em 18/10 o desenvolvedor respondeu que ainda não testou e pediu continuidade para testar a próxima entrega junto da primeira. Essa entrega foi concluída tecnicamente em [[Consolidacao UX e Ferramentas - 2026-10-18]]. A autorização de continuidade não é aprovação da experiência nem expansão de catálogo.

Na retomada inicial de 18/10, os 31 fontes anteriores foram reconferidos. A rodada posterior acrescentou três módulos e alterou cinco fontes existentes; resultados desta consolidação estão separados dos testes da primeira implementação.

Essa direção foi autorizada e implementada em [[Loja Upgrades e Index - 2026-10-18]]. Desenvolvedor testar os novos acessos, compras, Index e persistência/cotas. Manter o restante do roteiro manual pendente e ajustar a mesma base antes de escalar conteúdo.

Código: C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio.
Cópia anterior de fontes: contexto/antes-base-gameplay/studio-scripts.json.
Notas anteriores: contexto/obsidian-antes-implementacao-base.
Novo salvamento completo .rbxl/publicação não confirmado; fontes não substituem backup do lugar.
