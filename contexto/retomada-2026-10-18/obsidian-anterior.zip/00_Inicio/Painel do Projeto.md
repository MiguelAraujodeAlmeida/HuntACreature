---
tipo: painel
status: ativo
atualizado: 2026-10-17
---
# Hunt A Creature — painel do projeto

Memória de produto, decisões e validação. Leia [[Estado Atual]] antes de trabalhar. Código local em C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio; mapa/Tools/assets não estão integralmente exportados.

**Entrega vigente:** [[Base Mecanica - 2026-10-17]] — implementação aplicada ao Studio Edit, com testes manuais pendentes.

## Comece aqui

- **Diagnóstico:** [[Auditoria da Base Mecanica - 2026-10-17]].
- **Sequência de execução:** [[Plano da Base de Gameplay]] · [[Backlog]] · [[Roadmap]].
- **Cinco tópicos:** [[Combate]] · [[Progressao]] · [[Criaturas]] · [[Jogabilidade]] · [[Interacao]].
- **Visão:** [[Visao e Pilares]] · [[Loop e Sistemas]] · [[Direcao Visual e UX]].
- **Engenharia e processo:** [[Arquitetura Atual]] · [[Fluxo de Desenvolvimento]] · [[Qualidade e Testes]].
- **Validação pendente:** [[Correcao Laco e Passeio - 2026-10-17]] · [[Playtest Lumito - 2026-10-17]] · [[QA HUD e Audio - 2026-10-17]].
- **Decisões e referências:** [[ADR-001 - Fonte da verdade e sincronizacao]] · [[ADR-002 - Treino no manequim]] · [[Feedback Consolidado]] · [[Propostas de UX]] · [[Referencias Visuais]] · [[Arquivo - Contexto Inicial]].
- **Modelos:** [[Modelo - Funcionalidade]] · [[Modelo - Playtest]] · [[Modelo - Decisao]].

## Estado resumido

Base implementada com perfis persistentes, coleção individual, venda/troca/index, ferramentas, treino/upgrades e loja global com cota individual. Fontes comparados e sincronizados no Studio Edit. Verificações leves realizadas; gameplay e persistência real aguardam teste humano. Auditoria anterior descreve o ponto de partida, não esta entrega.

## Manutenção

Cada tópico é a referência de requisitos do seu domínio; o plano guarda ordem/dependências; backlog guarda estado. Atualizar Estado Atual ao concluir a sessão, evitando acumular versões contraditórias. Aprovação de experiência exige feedback humano. Assistente faz verificações leves e entrega checklist, sem Play/QA pesado autônomo.
