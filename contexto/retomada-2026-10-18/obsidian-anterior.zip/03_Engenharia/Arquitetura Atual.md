---
tipo: engenharia
status: observado
atualizado: 2026-10-17
---

# Arquitetura atual

## Implementação posterior à auditoria

O plano revisado foi implementado. GameplayConfig centraliza definições/curvas; ProfileData executa operações indivisíveis de coleção/economia; ProfileService cuida de persistência e posse da sessão. CreatureFactory preserva IDs/variações na representação visual, WorldPresentation apresenta base/manequim/loja e HuntingTools integra estímulos/efeitos à IA e captura. CollectionUI apresenta snapshots e solicita ações com revisão. Bootstraps integram os módulos existentes e novos.

Ver [[Base Mecanica - 2026-10-17]] e [[Estado Atual]]. As seções de auditoria abaixo são históricas: persistência e identidade já foram acrescentadas, mas ainda falta teste humano com DataStore real. Studio conectado e fontes sincronizados nesta entrega.

## Auditoria vigente

Ver [[Auditoria da Base Mecanica - 2026-10-17]] para evidências, grau de rigidez e fronteiras propostas. O Studio estava desconectado na consulta desta auditoria: os parágrafos de sincronização abaixo registram a entrega anterior. O novo [[Plano da Base de Gameplay]] ainda não foi implementado. Identidade das criaturas, capacidades e persistência são as principais dependências da expansão.

## Onde estão as peças

Após o primeiro playtest do Lumito: `HACServer.LassoCollision` separa contato contínuo do corpo móvel das regras de captura. `CaptureService` usa alcance integral da carga e varredura de obstáculos durante o voo; `CaptureConfig.LoopRadius` é compartilhado com a arte do anel. Passeio normal em `LumitoBehavior` tem temporizadores independentes de caminhar/pausar e parâmetros em `CreatureProfiles`. Ver [[Correcao Laco e Passeio - 2026-10-17]].

Comportamento adicionado em 17/10: `HACServer.CreatureBehaviorService` mantém agentes apenas para criaturas selvagens, com passos de movimento limitados a 20 Hz e percepção em intervalos. `CreatureProfiles` define espécie, parâmetros e chave do comportamento; `LumitoBehavior` contém a IA inicial. `BusyUserId` existente pausa o deslocamento durante captura. Modelos continuam ancorados e são movidos pelo servidor, com varredura de volume, ocupação no destino, separação entre agentes/personagens e limites do gramado. Não há navegação global de labirintos nesta fatia.

| Local no Studio | Cópia local | Responsabilidade atual |
|---|---|---|
| `ReplicatedStorage/HACShared` | `studio/shared/` | Configuração de captura e estilo visual |
| `ServerScriptService/HACServer` | `studio/server/` | Captura e validação de lançamento |
| `ServerScriptService` | `studio/HuntACreature.server.luau` | Mundo, criaturas, bases, treino e economia |
| `StarterPlayer/StarterPlayerScripts/HACClient` | `studio/client/` | HUD e controles |
| `StarterPlayer/StarterPlayerScripts` | `studio/HuntACreature.client.luau` | Inicialização do cliente |
| Mapa/Tools | Lugar do Studio | `BuildWorld.luau` histórico não foi recuperado neste computador |

Fonte detalhada: `C:\Users\melg_\Documents\ChatGPT\Hunt a Creature\studio\README.md`.

Atualização observada: `HACShared` inclui `LassoAim`, `LassoVisuals`, `WorldStyle` e `AudioConfig`. Cliente separa `HUDWidgets`, `GlossyButton`, `ResourceHUD`, `CaptureHUD`, `QuickSlot`, `UIEffects`, `LassoFeedback`, `HUDLayout` e `AudioFeedback`. `HUD` orquestra os componentes e `CaptureController` lê entrada; servidor continua autoridade. HUD criado em runtime sob `PlayerGui.HuntACreatureGui.AreaSegura` com CoreUISafeInsets.

## Fronteiras que queremos preservar

- **Servidor:** captura válida, inventário, moeda, upgrades e progressão. Nunca confiar em número/recompensa enviados pelo cliente.
- **Cliente:** entrada, mira prevista, HUD, câmera, efeitos locais. Mostrar resposta rápida sem declarar uma captura concluída antes da confirmação do servidor.
- **Dados compartilhados:** regras e constantes com versão clara; parâmetros de laço por tipo em vez de valores espalhados.
- **Conteúdo:** espécies, laços, modificadores e eventos em dados/configurações sempre que possível; lógica comum em serviços.

## Dívida conhecida

- `HuntACreature.server.luau` concentra vários sistemas. Extrair um domínio por vez quando receber trabalho nele; não fazer uma migração ampla sem teste de regressão.
- `HUD.luau` tem vários componentes em um arquivo. Separar por componente/contexto quando a UI mudar, com uma camada de estilo comum.
- O código local e a árvore de objetos do Studio foram mantidos manualmente. Ver [[ADR-001 - Fonte da verdade e sincronizacao]].
- Não há modelo de dados persistentes ou fluxo de release. Há verificações matemáticas pontuais da colisão, sem suíte abrangente nem aprovação da experiência. Testes maiores continuam manuais pelo desenvolvedor.
- O gerador histórico do mapa não está disponível localmente. Não reconstruir o cenário a partir de fontes parciais; preservar o lugar completo antes de alterar a construção.

## Regra para novas funcionalidades

Definir dono do estado, contrato de eventos, parâmetros de balanceamento e UI antes de codificar. Evitar que um pedido pequeno exija editar arquivos sem relação. Preferir alteração localizada, revisão leve e checklist manual dos caminhos afetados; testes extensivos só com pedido explícito.
