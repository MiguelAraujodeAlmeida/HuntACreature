---
tipo: plano
status: implementado_aguardando_playtest
atualizado: 2026-10-18
---
# Plano da base de gameplay

## Direção aprovada

Completar a base mecânica antes de ampliar conteúdo. O plano revisado foi autorizado para implementação; primeira versão aplicada ao Studio Edit. Não confundir entrega técnica com aprovação humana. Ver [[Base Mecanica - 2026-10-17]].

Decisões confirmadas: mesmas ofertas/rotação globais com **cota individual persistente**; **Lumito com tamanhos e mutação Dourado**, sem segunda espécie obrigatória; reaproveitar módulos e extrair apenas domínios necessários.

## Ordem e situação

| Etapa | Resultado solicitado | Situação |
|---|---|---|
| 1 — Caça confiável | Acerto consistente, pausas e laço levemente mais rápido | Laço 100, correção anterior preservada; aguarda reteste humano |
| 2 — Sensação de jogar | Ritmo, comandos, movimentação/câmera, HUD e som | Ritmo/mix/foco/input ajustados; câmera padrão preservada; avaliação humana pendente |
| 3 — Criaturas e dados | ID, espécie, tamanho, mutação, localização, capacidades, persistência | Implementado; serialização e sessão simuladas verificadas, DataStore real pendente |
| 4 — Coleção completa | Instalar, vender da bolsa/base, trocar com ambas cheias, index | Implementado; operações puras verificadas, UI/Play pendentes |
| 5 — Ferramentas | Uma isca, uma armadilha de chão e uma poção durante captura | Implementado; comportamento e posicionamento aguardam Play |
| 6 — Progressão | Manequim e cinco upgrades com benefício perceptível | Implementado com três melhorias por categoria; economia inicial pendente de balanceamento humano |
| 7 — Loja no hub | Rotação aleatória global, cotas individuais e compras | Implementado; regras simuladas verificadas; teste real em dois servidores pendente |
| 8 — Consolidação | Ciclo completo e maleabilidade confirmados | Integração técnica revisada; aceitação final depende do desenvolvedor |

## Critérios de conclusão

Capturar → reconhecer variação → guardar → instalar/vender/trocar → melhorar/treinar → comprar ferramentas → caçar novamente. Esse ciclo deve conservar identidade e progresso, ter comandos claros e oferecer vontade de repetir. Descoberta não some ao vender; cota não repõe ao trocar servidor; troca não exige espaço vazio transitório.

HUD, som e controles acompanham todas as entregas. A base só será considerada aprovada após o parecer do desenvolvedor.

## Limites

Mantidos: sete raridades na ordem em [[Criaturas]], estrutura para expansão, coleção persistente e validação no servidor. Removidas como obrigações: segunda espécie, novo modelo de laço, sistema de níveis XP, sprint/dash, bônus perfeito, eventos e PvP completo. Interferência continua hipótese.

Texturas, teletransporte, animação/modelo final e configurações de áudio permanecem adiados. Não adicionar mute nas abas.

## Verificação e próximos ajustes

Verificações leves já realizadas estão em [[Base Mecanica - 2026-10-17]]. Checklist manual cobre caça; áudio/HUD; coleção cheia; ferramentas; treino/upgrades; loja; reconexão. Executar por partes conforme o domínio afetado; não realizar testes pesados automaticamente.

A consolidação pode avançar em entregas específicas autorizadas antes do playtest; ajustes de diversão e balanceamento dependem do parecer dessa versão. Não escalar catálogo, mapa ou sistemas.

## Rodada de consolidação — 18/10/2026

Continuação solicitada pelo desenvolvedor. Ele confirmou que ainda não testou a base e autorizou avançar uma entrega para testar ambas juntas. [[Consolidacao UX e Ferramentas - 2026-10-18]] implementada e aplicada ao Studio Edit: posicionamento legível, estabilidade dos painéis/revisões durante renda, seleção/recarga, disponibilidade de compra e clareza da troca/index. Não há aprovação de experiência; prioridades abaixo continuam organizando correções do escopo existente.

| Ordem | Foco | Entrega seguinte | Condição para encerrar |
|---|---|---|---|
| 1 | Bloqueios e integridade | Corrigir falhas reproduzíveis de entrada, captura, inventário, compra ou salvamento que apareçam no teste | Caminho afetado funciona no reteste humano, sem perda/duplicação ou controles presos |
| 2 | Caça e resposta | Ajustar um problema de ritmo, controle, legibilidade ou áudio por entrega | Desenvolvedor reconhece melhoria e consegue explicar o resultado de acerto/erro |
| 3 | Utilidade das ferramentas | Comparar abordagem sem ferramenta e com uma ferramenta; ajustar efeito, indicação ou custo se não houver vantagem percebida | Cada ferramenta tem uma situação útil; laço básico continua viável |
| 4 | Progressão e economia | Ajustar preços/ganhos a partir do ciclo observado, preservando as cinco categorias | Próxima melhoria é compreensível e seu benefício aparece na jogabilidade |
| 5 | Integração final | Confirmar reconexão, rotação/cotas entre servidores e telas afetadas | Checklist pertinente concluído e parecer humano registrado |

Bloqueios de dados e progresso têm prioridade em qualquer etapa. Não esperar o final para corrigir um problema de persistência. Fazer uma entrega principal por vez e retestar apenas os caminhos afetados.

### Primeiro roteiro manual, se a versão ainda não foi testada

Capturar um Lumito → abrir a bolsa → instalar na base → capturar outro → vender pela bolsa → verificar ouro e index. Relatar o primeiro ponto que falhar ou parecer ruim. Esse percurso inicial não substitui os testes posteriores de troca cheia, ferramentas e persistência; evita pedir toda a matriz de uma vez.

Se já houve teste, partir dos relatos existentes em vez de repetir o roteiro. Para cada problema basta registrar ação, resultado observado e resultado esperado; dispositivo quando o problema envolver interface/controles.

### Pontos de atenção identificados nos parâmetros atuais

- Um Lumito normal de tamanho 1 vende por 12 ouro, e uma armadilha custa 12. O consumível precisa justificar o gasto em uma situação concreta; isso é hipótese de balanceamento, não evidência de falha.
- Três Lumitos normais de tamanho 1 instalados geram 3 ouro por 5 s. Partindo de zero ouro e sem outros ganhos/gastos, a primeira melhoria de bolsa (25 ouro) exige nove pagamentos, cerca de 45 s. Esse cálculo não inclui tempo de caça/deslocamento e não define a duração desejada de progressão.
- A loja oferece duas das três ferramentas por janela de cinco minutos. Verificar se a ausência temporária produz escolha útil ou espera sem propósito; não alterar a rotação sem esse contexto.
- O laço do catálogo é o inicial já adquirido. Há catálogo/compra genérica implementados, mas ainda não há outro laço comprável para criar progressão de equipamento. O plano revisado dispensou novo laço nesta fase; registrar essa limitação sem apresentar variedade de laços como entregue.

Esses pontos orientam a conversa de balanceamento. Nenhum preço, efeito ou duração foi alterado nesta continuação. Não transformar sugestões em tarefas obrigatórias.
