---
tipo: planejamento
status: aguardando_playtest
atualizado: 2026-10-18
---
# Backlog

Ordem vigente em [[Plano da Base de Gameplay]]. Entrega e checklist em [[Base Mecanica - 2026-10-17]]. IDs anteriores preservados; etapas renumeradas conforme o plano revisado.

**Pronto para playtest** significa implementado, não aprovado. Verificações leves não substituem experiência nem DataStore real. Próxima prioridade: feedback e correções dessa base, sem ampliar o catálogo.

Revisão mais recente: [[Loja Upgrades e Index - 2026-10-18]], autorizada após a pesquisa e aplicada ao Studio Edit. 37 fontes finais conferidos; acessos individuais, catálogo configurável e botão próprio de Index aguardam parecer humano.

Em 18/10, o desenvolvedor confirmou não ter testado e autorizou avançar para testar duas entregas juntas. [[Consolidacao UX e Ferramentas - 2026-10-18]] pronta: prévia, disponibilidade, estabilidade com renda e clareza da coleção. Parecer humano pendente.

| ID | Entrega | Etapa | Estado / evidência |
|---|---|---|---|
| PROC-01 | Conferência e recuperação | Transversal | 31 fontes locais/Studio conferidos em 18/10; cópia de scripts preservada; backup completo do lugar/publicação não confirmado |
| HAC-03 | Contato com alvo móvel | 1 | Pronto para playtest; correção geométrica anterior preservada |
| HAC-04 | Passeio, visão, fuga, cansaço e pausas | 1 | Pronto para playtest; primeiro parecer não aprova revisão atual |
| HAC-03A | Laço levemente mais veloz | 1 | Pronto para playtest; 100 studs/s aplicado |
| HAC-01 | HUD adaptável e coleção | 2 / contínua | Pronto para playtest; telas novas precisam avaliação humana |
| HAC-02 | Ritmo e legibilidade da disputa | 2 | Pronto para playtest; parâmetros ajustados |
| HAC-05 | Áudio satisfatório e feedback | 2 | Pronto para playtest; mix ajustado, parecer auditivo pendente |
| HAC-11 | Clareza dos comandos e próximos passos | 2 / contínua | Instruções contextuais implementadas; avaliar entendimento; sem tutorial extenso novo |
| HAC-15 | Identidade, variações, raridades e capacidades | 3 | Pronto para playtest; regras/serialização verificadas |
| HAC-12 | Perfil versionado e persistência | 3 | Pronto para playtest; sessão simulada verificada; DataStore real pendente |
| HAC-16 | Cartões individuais de bolsa/base | 4 | Pronto para playtest; renda não recria cartões; foco/rolagem preservados quando aplicável |
| HAC-17 | Venda na bolsa e na base | 4 | Pronto para playtest; regra contra venda repetida verificada |
| HAC-18 | Troca com ambas cheias | 4 | Pronto para playtest; capacidade/IDs preservados nas verificações |
| HAC-19 | Index de descobertas | 4 | Revisão pronta: botão próprio, filtro, paginação e ficha; venda não remove descoberta |
| HAC-20 | Seleção de ferramentas e efeitos | 5 | Pronto para playtest; prévia e motivo de impedimento, seleção/quantidade/recarga; toque/controle pendentes |
| HAC-21 | Isca | 5 | Pronto para playtest |
| HAC-22 | Armadilha posicionável | 5 | Pronto para playtest |
| HAC-23 | Poção durante disputa | 5 | Pronto para playtest |
| HAC-24 | Curvas centrais de economia e atributos | 6 | Pronto para playtest; números provisórios; novo sistema de níveis XP excluído |
| HAC-06 | Treino automático no manequim | 6 | Pronto para playtest; [[ADR-002 - Treino no manequim]] |
| HAC-13 | Cinco categorias de upgrades | 6 | Revisão pronta: acessos individuais, três melhorias por categoria, prévia de treino/eficiência |
| HAC-25 | Loja global com cota individual | 7 | Revisão pronta: catálogo completo, chance/quantidade por item, cota preservada; dois servidores reais pendentes |
| HAC-26 | Integração e maleabilidade | 8 | Consolidação aplicada: regras de posicionamento compartilhadas e renda sem invalidar ações; ciclo completo e aprovação humana pendentes |
| HAC-27 | Interferência durante captura | Depois da base | Hipótese; não implementada; não impede concluir a base |

## Fora da execução atual

| ID | Tema | Estado |
|---|---|---|
| HAC-01A | Amostra artística final | Adiado |
| HAC-07 | Teletransporte | Adiado pelo desenvolvedor |
| HAC-08 | Mapa amplo e novas áreas | Expansão posterior |
| HAC-09 | Texturas finais | Adiado pelo desenvolvedor |
| HAC-10 | Pipeline/modelos e animação de locomoção | Polimento adiado |
| HAC-14 | Configurações e áudio | Adiado; sem mute nas abas |
| EXP-01 | Catálogo amplo, segunda espécie, eventos e social complexo | Futuro; novo escopo |

## Processo

Uma entrega principal por vez. Corrigir com caso reproduzível e checklist dos caminhos afetados. Assistente faz apenas revisão/verificação leve; testes maiores exigem pedido explícito. Registrar feedback do desenvolvedor antes de mudar qualquer item para Aprovado.
