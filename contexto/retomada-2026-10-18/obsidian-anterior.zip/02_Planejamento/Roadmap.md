---
tipo: planejamento
status: aguardando_playtest
atualizado: 2026-10-17
---
# Roadmap

O [[Plano da Base de Gameplay]] revisado foi autorizado e recebeu sua primeira implementação. [[Base Mecanica - 2026-10-17]] registra entrega, limites e testes. [[Backlog]] mantém IDs.

1. **Validar caça e UX:** laço, IA, controles, HUD e som.
2. **Validar ciclo da coleção e persistência:** capturar, instalar, vender, trocar e reconectar.
3. **Validar ferramentas e progressão:** isca, armadilha, poção, manequim e cinco upgrades.
4. **Validar economia integrada:** rotação global com cotas individuais e compra.
5. **Consolidar:** corrigir falhas e aprovar a base pelo playtest humano.
6. **Depois:** expandir espécies, mapas e complexidade com escopo próprio.

Não iniciar automaticamente segunda espécie, PvP, eventos, teletransporte, arte final ou sistema de níveis XP. Interação permanece hipótese; modelo/animação e texturas seguem adiados.
