---
tipo: planejamento
status: aguardando_playtest
atualizado: 2026-10-18
---
# Backlog

Entrega vigente: [[Menus Placas e Inventario - 2026-10-18]]. **Pronto para playtest** significa implementado, não aprovado. Próxima prioridade: feedback dessa fatia, sem ampliar catálogo. Plano e limites em [[Plano da Base de Gameplay]].

| ID | Entrega | Etapa | Estado / evidência |
|---|---|---|---|
| PROC-01 | Conferência e recuperação | Transversal | 37 fontes atuais recuperados do Studio; baseline 7b2649a; 42 finais iguais/compilados; backup completo .rbxl não confirmado |
| HAC-03 | Contato com alvo móvel | 1 | Pronto para playtest; correção geométrica anterior preservada |
| HAC-04 | Passeio, visão, fuga, cansaço e pausas | 1 | Pronto para playtest; primeiro parecer não aprova revisão atual |
| HAC-03A | Laço levemente mais veloz | 1 | Pronto para playtest; 100 studs/s aplicado |
| HAC-01 | HUD adaptável e menus | 2 / contínua | Menus enxutos, Criaturas e Index separados; interação/legibilidade pendentes de parecer humano |
| HAC-02 | Ritmo e legibilidade da disputa | 2 | Pronto para playtest; parâmetros ajustados |
| HAC-05 | Áudio satisfatório e feedback | 2 | Pronto para playtest; mix ajustado, parecer auditivo pendente |
| HAC-11 | Clareza sem tutoriais excessivos | 2 / contínua | Guias redundantes e acessos repetidos removidos; avaliar entendimento pelo uso |
| HAC-15 | Identidade, variações, raridades e capacidades | 3 | Pronto para playtest; regras/serialização verificadas |
| HAC-12 | Perfil versionado e persistência | 3 | Pronto para playtest; sessão simulada verificada; DataStore real pendente |
| HAC-16 | Gerenciamento em Criaturas | 4 | Equipar/Desequipar contextuais, filtros e renda/s; regras verificadas, interação pendente |
| HAC-17 | Venda no mercado físico | 4 | Balcão no hub, confirmação individual, proximidade validada; venda removida do menu Criaturas |
| HAC-18 | Substituir troca por equipar/desequipar | 4 | Swap removido; capacidade livre no destino obrigatória; bolsa cheia não perde indivíduo |
| HAC-19 | Index de descobertas | 4 | Revisão pronta: botão próprio, filtro, paginação e ficha; venda não remove descoberta |
| HAC-20 | Inventário nativo de ferramentas | 5 | Só Tools possuídos; reordenação nativa; zeros removidos, objetos estáveis; input/respawn pendentes |
| HAC-21 | Isca | 5 | Pronto para playtest |
| HAC-22 | Armadilha posicionável | 5 | Pronto para playtest |
| HAC-23 | Poção durante disputa | 5 | Integração com Tool equipado; disputa não depende de continuar segurando o laço; testar manualmente |
| HAC-24 | Curvas de economia e atributos | 6 | Renda de ouro/XP a cada 1 s, ganhos 5× por escolha explícita; preços mantidos e balanceamento pendente |
| HAC-06 | Treino automático no manequim | 6 | Pronto para playtest; [[ADR-002 - Treino no manequim]] |
| HAC-13 | Cinco categorias nas placas | 6 | Base/Bolsa/Velocidade na frente; Treino/Multiplicador no posto; compras individuais sem menu alternativo |
| HAC-25 | Loja global com cota individual | 7 | Revisão pronta: catálogo completo, chance/quantidade por item, cota preservada; dois servidores reais pendentes |
| HAC-26 | Integração e maleabilidade | 8 | WorldStations/UpgradeBoards/CreaturePage/ToolInventory/NativeInventory separados; ciclo humano pendente |
| HAC-27 | Interferência durante captura | Depois da base | Hipótese; não implementada; não impede concluir a base |

## Fora da execução atual

| ID | Tema | Estado |
|---|---|---|
| HAC-01A | Amostra artística final | Adiado |
| HAC-07 | Teletransporte | Adiado pelo desenvolvedor |
| HAC-08 | Mapa amplo e novas áreas | Expansão posterior |
| HAC-09 | Texturas finais | Adiado pelo desenvolvedor |
| HAC-10 | Pipeline/modelos e animação de locomoção | Polimento adiado |
| HAC-14 | Configurações e áudio | Adiado; sem mute nas abas |
| EXP-01 | Catálogo amplo, segunda espécie, eventos e social complexo | Futuro; novo escopo |

## Processo

Uma entrega principal por vez. Corrigir com caso reproduzível e checklist dos caminhos afetados. Assistente faz apenas revisão/verificação leve; testes maiores exigem pedido explícito. Registrar feedback do desenvolvedor antes de mudar qualquer item para Aprovado.
