---
tipo: pesquisa
status: concluida_sem_implementacao
atualizado: 2026-10-18
---
# Pesquisa comparativa de sistemas — 18/10/2026

> Registro histórico desta rodada. O estado vigente está em [[Estado Atual]]; acessos de upgrades, troca e venda foram revistos em [[Menus Placas e Inventario - 2026-10-18]]. Caminhos locais abaixo podem pertencer ao outro dispositivo.

## Pedido e decisões do desenvolvedor

Pesquisar Grow a Garden, Steal an Egg e Steal a Brainrot, comparando seus sistemas com os que existem no Hunt a Creature. O desenvolvedor confirmou que “Steel, Abernoth” significava **Steal a Brainrot**.

- Loja e upgrades atuais não correspondem à experiência desejada.
- As melhorias devem ser individuais: base, treino, bolsa, multiplicador de evolução da força e velocidade.
- **Index deve ter botão próprio no HUD.** O acesso atual por uma aba do painel de coleção não atende ao pedido.
- Esta entrega é pesquisa e recomendação. Nenhuma alteração de gameplay foi realizada.

## Método e limites

Consulta às descrições oficiais no Roblox, guias publicados, documentação comunitária e imagem de referência já fornecida pelo desenvolvedor. Comparação com fontes locais em `studio`, especialmente GameplayConfig, ProfileData e CollectionUI, e com o Estado Atual do Obsidian. A captura local de Steal an Egg mostra um botão azul Index abaixo de Shop.

Não foram iniciadas sessões dos jogos de referência nem Play no Studio. Esta pesquisa não mede ritmo real, qualidade sonora, controles ou retenção. Os detalhes comunitários são relatos documentados, não auditoria dos servidores dos jogos. Não foi feita nova sincronização local/Studio; as observações de implementação abaixo se referem aos fontes locais da entrega registrada.

Foram separados o Grow a Garden original de Grow a Garden 2 e Steal an Egg de Break and Steal an Egg. As referências oficiais utilizadas são [Grow a Garden](https://www.roblox.com/games/126884695634066/Grow-a-Garden), [Steal an Egg](https://www.roblox.com/games/107778070777162/Steal-An-Egg) e [Steal a Brainrot](https://www.roblox.com/games/109983668079237/Steal-a-Brainrot).

Algumas fontes descrevem versões de 2025 e outras atualizações de 2026. Preços, número de criaturas, probabilidades e fórmulas exatas não são tratados como valores atuais garantidos. Páginas Fandom bloqueadas para abertura foram consultadas por seus trechos indexados. O site stealabrainrot.wiki declara reutilizar conteúdo da Fandom: não são duas confirmações independentes.

## 1. Loja: o que aproveitar de Grow a Garden

A Seed Shop mantém itens do catálogo visíveis mesmo quando indisponíveis. A documentação descreve reposição principal a cada cinco minutos, seleção inicial compartilhada entre servidores e compras que reduzem apenas a disponibilidade pessoal. Há sementes básicas recorrentes e itens raros menos frequentes; o estado esgotado aparece como “NO STOCK”. A Gear Shop oferece outra categoria de compras. Isso é mais específico que simplesmente escolher alguns itens aleatórios e esconder os demais. Fontes: [Seed Shop](https://growagarden.fandom.com/wiki/Seed_Shop), [Gear Shop](https://growagarden.fandom.com/wiki/Gear_Shop).

A loja também precisa comunicar utilidade: sementes diferem em custo e produção, incluindo colheita única ou recorrente. Assim, a decisão não se resume à raridade. Existem extensões como Daily Deals, mas não são necessárias para reproduzir o funcionamento básico que interessa ao projeto. [Guia de sementes e loja](https://beebom.com/grow-a-garden-seed-shop-guide/).

**Diferença atual no Hunt a Creature:** a cada cinco minutos, o código escolhe dois entre três consumíveis; somente ofertas presentes são exibidas. O laço inicial aparece no catálogo, mas já pertence ao jogador. A rotação e as cotas pessoais persistentes já existem. Falta apresentar o catálogo completo e permitir regras de reposição por item, em vez de uma seleção fixa de duas opções equivalentes.

**Adaptação recomendada, ainda não implementada:**

1. Manter todos os itens comercializáveis cadastrados visíveis, com estado disponível, esgotado ou já adquirido.
2. Mostrar efeito, duração/uso, preço, quantidade pessoal restante e contador único da próxima reposição.
3. Definir por item chance de aparecer e faixa de quantidade; permitir algum recurso básico sempre disponível. Não fixar probabilidades antes do playtest da economia.
4. Preservar mesmas ofertas globais e cotas individuais ao reconectar, conforme decisão já tomada para o nosso jogo.
5. Separar equipamentos permanentes dos consumíveis. Um laço possuído precisa dizer “Adquirido”; não deve parecer uma compra nova.
6. Manter upgrades permanentes fora do sorteio de estoque. A evolução escolhida pelo jogador não precisa depender de sorte na loja.

Não foi confirmado diretamente o comportamento de todas as cotas de Grow a Garden após reconexão. Preservá-las no Hunt a Creature é requisito próprio já autorizado. Também não foi verificado o algoritmo interno da referência; os termos “client-sided” usados em algumas páginas não provam que compras dispensem validação do servidor.

## 2. Upgrades: o que aproveitar de Steal an Egg

A descrição oficial confirma treino em esteira e melhorias de esteira e base. Guias descrevem a compra da melhoria junto à máquina e Trails como uma via adicional de bônus. São investimentos com funções distintas, em vez de um único nível que melhora toda a conta. [Descrição oficial](https://www.roblox.com/games/107778070777162/Steal-An-Egg), [treino e Trails](https://beebom.com/how-to-increase-speed-in-steal-an-egg/).

A documentação comunitária distingue capacidade de pets ativos, qualidade da esteira e bônus equipado. Ela também diferencia o atributo acumulado Speed Power da velocidade física em studs/s: um número grande no HUD não significa correr literalmente naquela velocidade. Há divergências entre guias sobre fatores e quantidades; não adotar uma fórmula exata sem observação direta. [Capacidade da base](https://stealanegg-wiki.com/wiki/base-upgrades), [Speed e movimento](https://stealanegg-wiki.com/wiki/speed), [Trails](https://stealanegg-wiki.com/wiki/trails).

**Diagnóstico do nosso jogo:** as cinco categorias já são independentes em `ProfileData.Action`: comprar um upgrade incrementa somente seu identificador. Entretanto, todas aparecem em cartões semelhantes na aba Melhorias, e o acesso exige proximidade da base. A lógica atende à separação; a apresentação ainda não dá identidade e contexto suficientes a cada escolha.

Não substituir o manequim por uma esteira: o treino com laço foi uma decisão anterior explícita. Aproveitar a organização da progressão, mantendo a identidade do projeto.

| Caminho independente | Benefício próprio | Proposta de acesso e informação |
|---|---|---|
| Base | Mais criaturas instaladas simultaneamente | Controle na própria base; mostrar lugares atuais → próximos |
| Treino | Mais força básica por ciclo do manequim | Interação no manequim; mostrar ganho básico e intervalo |
| Multiplicador | Aumentar o rendimento do ganho de força | Opção separada no contexto do treino; mostrar fator e ganho final |
| Bolsa | Mais capturas antes de retornar | Acesso junto à capacidade da bolsa; mostrar espaços atuais → próximos |
| Velocidade | Deslocamento melhor durante a caça | Acesso próprio; mostrar velocidade atual → próxima, sem confundir com força |

Os locais de acesso são sugestões desta pesquisa, não decisões já aprovadas. Cada compra deve ter custo e nível próprios, sem exigir comprar as outras categorias. Não há necessidade de introduzir Trails como conteúdo para conseguir essa separação.

Exemplo com a configuração atual: treino básico de 2 força por ciclo e multiplicador de 1,5 resultam em 3. Melhorar só o treino para 3 resulta em 4,5; melhorar só o multiplicador de 1,5 para 2 resulta em 4. O painel precisa mostrar esse resultado, não apenas nomes técnicos. Os valores são provisórios.

Steal a Brainrot liga parte da progressão a Rebirth, com requisitos e desbloqueios de capacidade, renda ou equipamentos. Esse modelo não equivale às cinco melhorias independentes solicitadas e não deve ser importado nesta etapa. As fontes divergem sobre perdas exatas em diferentes versões de Rebirth; não se recomenda nenhuma mecânica de reset. [Rebirth](https://stealabrainrot.wiki/wiki/rebirth/).

## 3. Index: acesso, registro e recompensa são decisões separadas

| Referência | Funcionamento documentado | O que aproveitar |
|---|---|---|
| Grow a Garden | Garden Guide reúne catálogos e informações de plantas, pets e outras categorias; também há conquistas. A wiki registra que passou de item/livro para botão lateral. | Acesso rápido e consulta que ajuda a entender o conteúdo |
| Steal an Egg | Botão azul Index; espécies agrupadas em coleções por mundo, recompensa de descoberta e equipamento por completar determinadas coleções. Duplicatas não contam como novas espécies. | Tornar uma descoberta nova um acontecimento claro |
| Steal a Brainrot | Silhuetas para não descobertos, registro por mutação e metas que podem conceder bônus da base ou aparência. Requisitos variam entre coleções permanentes e sazonais. | Tornar variantes relevantes para a coleção, além do preço |

Fontes: [Garden Guide](https://growagarden.fandom.com/wiki/Garden_Guide), [Index de Steal an Egg](https://stealanegg-wiki.com/wiki/index), [Index de Steal a Brainrot](https://stealabrainrot.wiki/wiki/index/). A imagem local de Steal an Egg também confirma visualmente seu botão independente: [[Referencias Visuais]].

**Hoje:** nosso Index é uma aba de CollectionUI. Guarda descoberta por espécie ao capturar, mostra contagem e preserva descoberta após venda. Não guarda descoberta separada por mutação ou recorde de tamanho e não concede prêmio resgatável.

**Confirmado pelo desenvolvedor:** botão próprio Index no HUD, abrindo diretamente a coleção. Não exigir passar pela bolsa.

**Recomendado para uma próxima entrega:** painel com silhueta/estado desconhecido, espécie descoberta, raridade e progresso. Ficha que explique características relevantes; indicação de descoberta nova sem bloquear a captura seguinte. Preservar a diferença entre “já descobri” e “possuo agora”.

**Candidatos posteriores, ainda não requisitos:** registro de Dourado, maior tamanho capturado e recompensa única de descoberta. Com apenas Lumito, não criar metas de dezenas de espécies nem bônus permanentes de coleção completa. Recompensas por conjunto devem esperar conteúdo e economia que as sustentem.

## 4. Comparação dos demais sistemas existentes

As linhas abaixo comparam os equivalentes mais próximos. “Sem equivalente central identificado” não significa que nunca tenha existido um evento com função parecida.

| Sistema | Hunt a Creature — fontes locais | Grow a Garden | Steal an Egg | Steal a Brainrot |
|---|---|---|---|---|
| Aquisição principal | Caçar e capturar com laço | Comprar, plantar, esperar e colher | Pegar ovo, escapar do guardião, levar à base e chocar | Comprar criaturas ou roubá-las de jogadores |
| Desafio ativo | Mira, carga e minigame de disputa | Gestão do jardim; sem disputa de laço equivalente identificada | Rota e fuga com ovo | Transporte e defesa/contra-ataque entre jogadores |
| Comportamento | Lumito passeia, pausa, percebe, foge e cansa | Pets auxiliam a produção; papel diferente de presa | Guardiões protegem ninhos e perseguem | Criaturas são sobretudo aquisição, coleção e renda |
| Variantes | Tamanhos e Dourado no Lumito | Peso/tamanho e mutações alteram valor | Tamanho e mutações diferenciam pets | Mutações e traits modificam exemplares e renda |
| Base e economia | Criaturas instaladas geram ouro periodicamente | Jardim produz colheitas para vender | Pets ativos produzem renda | Criaturas na base produzem dinheiro |
| Venda | Por indivíduo na bolsa ou base | Venda da produção faz parte do ciclo principal | Gestão dos pets envolve renda e seleção | Venda contextual de criaturas na base |
| Armazenamento | Bolsa e base com capacidades; troca mesmo cheias | Inventário de pets distinto dos pets ativos | Coleção de pets distinta da capacidade ativa | Espaço de base é importante; não equivale à nossa troca bolsa/base |
| Ferramentas | Isca, armadilha e poção com consumo/recarga | Equipamentos alteram crescimento e manejo | Equipamentos ajudam fuga/interferência | Equipamentos apoiam defesa, ataque e transporte |
| Treino e deslocamento | Manequim aumenta força; velocidade é upgrade separado | Sem treino de caça equivalente identificado | Treino de velocidade tem papel central | Progressão central não depende de treino em manequim |
| Coleção | Descobertas persistentes por espécie | Vários catálogos dentro do Guide | Descoberta e coleções de mundos | Catálogos relacionados a mutações |
| Interface | HUD responsivo; vários sistemas concentrados num painel | Lojas e Guide têm funções separadas | Index, loja e melhorias contextuais | Base, Index e lojas têm papéis próprios |
| Persistência/offline | Perfil salvo; sem produção offline implementada | Crescimento offline anunciado oficialmente | Guias relatam ganhos offline | Documentação relata renda offline |
| Interação social | Hipótese ainda não implementada | Ajudas/trocas documentadas; estrutura distinta de combate | Disputa por ovos e interferência | Roubo e defesa constituem o núcleo |

Fontes para os ciclos: descrições oficiais acima e [guia de Steal an Egg](https://games.gg/roblox/guides/steal-an-egg-beginner-guide/). Para capacidades: [Pet Pouch de Grow a Garden](https://beebom.com/grow-a-garden-pet-pouch-guide-how-to-increase-pet-inventory/) e [base de Steal a Brainrot](https://stealabrainrot.wiki/wiki/base/). Para ferramentas: [gears de Grow a Garden](https://growagarden.fandom.com/wiki/Gears), [equipamentos de Steal an Egg](https://stealanegg-wiki.com/wiki/bats) e [gears de Steal a Brainrot](https://stealabrainrot.wiki/wiki/gears/).

Fontes complementares: [venda na base](https://stealabrainrot.wiki/wiki/grab/sell/), [mutações de Steal an Egg](https://stealanegg-wiki.com/wiki/mutations), [mutações](https://stealabrainrot.wiki/wiki/mutations/) e [traits](https://stealabrainrot.wiki/wiki/traits/) de Steal a Brainrot; [introdução de trocas em Grow a Garden](https://www.pcgamer.com/games/survival-crafting/grow-a-gardens-newest-update-has-introduced-cooking-alongside-a-feature-that-players-have-been-begging-for/).

**Consequências para nosso design — interpretação:**

- A troca bolsa/base já resolve um problema útil do nosso ciclo. Não precisa ser descartada para imitar outra referência.
- Duplicatas precisam continuar tendo valor de venda ou substituição na base. Coleção não pode ser o único motivo para capturar.
- Mostrar renda do exemplar e valor de venda ajuda a decidir entre instalar, trocar e vender. Raridade, tamanho e mutação devem explicar o resultado, sem copiar fórmulas incompatíveis entre jogos.
- Evoluir velocidade precisa ajudar sem eliminar a perseguição. Evoluir força precisa facilitar sem tornar o minigame uma formalidade. Isso depende de playtest humano.
- Cada ferramenta deve resolver uma situação reconhecível: atrair, controlar deslocamento ou ajudar durante a disputa. Não basta aumentar quantidade de botões.

## 5. Som, feedback e experiência

Não houve escuta comparativa dos jogos; não há base para afirmar que um timbre, mix ou asset específico deles seja superior. A documentação de Steal a Brainrot descreve alerta visual e sonoro quando ocorre roubo, um exemplo de áudio informando um evento relevante. [Stealing](https://stealabrainrot.wiki/wiki/stealing/).

Para Hunt a Creature, a proposta é manter sinais diferentes para lançamento, contato válido, tensão da disputa, captura e primeira descoberta. Compra e upgrade devem confirmar a ação com benefício visível. Renda recorrente precisa ser discreta para não competir continuamente com a caça. São recomendações de feedback, não garantias de retenção ou de resposta emocional.

O som atual e o ritmo do minigame continuam dependendo do parecer do desenvolvedor. Não colocar mute em cada painel; configurações de áudio permanecem para a futura aba de configurações.

## 6. O que não importar nesta rodada

Os jogos de referência também documentam sistemas como eventos, fabricação/fusão, expansões de mundos, receitas, negociação, passes e Rebirth. Essa pesquisa não os transforma em requisitos. Não é necessário reproduzir todos os eventos, catálogos ou métodos de monetização para comparar os sistemas que nosso jogo já tem.

Roubo permanente de criaturas ou perda de progresso não estão autorizados. Interferência entre jogadores continua uma hipótese para depois do ciclo individual. Segunda espécie, texturas, teletransporte e animação final seguem adiados. Crescimento ou renda offline nas referências não equivalem ao nosso salvamento de perfil, e não autorizam adicionar renda offline agora.

Há divergências de fontes sobre ganhos offline e custos atuais. Nenhum percentual, limite de horas, preço de Robux ou fórmula interna desses sistemas deve ser copiado com base nesta pesquisa.

## 7. Sequência recomendada para a próxima implementação

1. **Apresentação dos upgrades:** manter dados independentes; separar acessos e mostrar benefício atual/próximo, custo e efeito final do treino. Preservar perfis existentes.
2. **Loja:** catálogo visível, reposição configurável por item e informação de uso/estoque. Preservar rotação global e cota pessoal persistente.
3. **Index:** botão próprio e tela direta. Variantes e recompensas só entram se forem escolhidas como entrega adicional.

Essas mudanças reutilizam a base implementada. Não exigem reescrever captura, IA, armazenamento ou transferências. A ordem é recomendação; esta entrega não alterou runtime nem aplicou mudanças ao Studio.

Quando implementadas, o desenvolvedor poderá verificar manualmente: comprar uma melhoria e conferir que só ela mudou; diferenciar treino/multiplicador; esgotar a própria cota e reconectar; comparar lojas em dois servidores; abrir Index direto no HUD e conferir descoberta após venda. Nenhuma dessas verificações foi executada nesta pesquisa.

Relacionados: [[Estado Atual]], [[Progressao]], [[Jogabilidade]], [[Feedback Consolidado]], [[Plano da Base de Gameplay]].
