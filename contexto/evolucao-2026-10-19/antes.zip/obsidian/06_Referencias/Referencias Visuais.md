---
tipo: referencia
status: historico
atualizado: 2026-10-16
---

# Referências visuais fornecidas

As imagens abaixo foram enviadas pelo desenvolvedor. Servem para lembrar **o que foi observado**, sem virar uma obrigação de copiar outro jogo. A direção atual está em [[Direcao Visual e UX]].

## Exemplo de Steal an Egg

![[referencia-steal-an-egg.png|900]]

Leitura extraída do feedback: ações nas laterais, recursos visíveis com ícones, contraste forte, mapa lúdico e modular, sensação de atividade e recompensa. O título grande visto nessa captura foi parte do tutorial do jogo de referência e **não** deve permanecer no HUD de Hunt A Creature.

## HUD da primeira revisão

![[hud-primeira-revisao.png|700]]

Problemas relatados: caixas e tipografia genéricas, excesso de texto, sobreposição no centro inferior, falta de personalidade e sinais visuais autoexplicativos.

## Minigame da primeira revisão

![[minigame-primeira-revisao.png|500]]

Problemas relatados: painel grande, texto tutorial excessivo, pouca sensação de disputa/conquista. A revisão v2 ainda aguarda avaliação humana.
