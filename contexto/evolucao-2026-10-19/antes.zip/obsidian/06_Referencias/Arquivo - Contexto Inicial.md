---
tipo: arquivo_historico
status: substituido_em_parte
atualizado: 2026-10-16
---

> Registro original de ideias. Algumas propostas foram substituídas pelo feedback posterior, especialmente treino em esteira, ponte e HUD com instruções. Consultar [[Estado Atual]] e [[Feedback Consolidado]] antes de usar este arquivo como referência.

# Hunt A Creature — Contexto Geral do Projeto

> **Finalidade deste arquivo:** apresentar ao Codex a visão do jogo e as decisões já discutidas, sem funcionar como um plano de execução, uma lista de tarefas ou uma arquitetura obrigatória. O desenvolvedor decidirá o que implementar e em qual ordem, por meio de solicitações específicas.

## 1. Visão do jogo

**Nome:** Hunt A Creature  
**Plataforma:** Roblox  
**Gênero:** jogo multiplayer de caça e coleção de criaturas, com progressão incremental, produção passiva de recursos e eventos recorrentes.

A proposta é criar um jogo fácil de entender, com mecânicas acessíveis, progresso visível e variedade de criaturas. A inspiração de *ritmo e estrutura* vem de experiências como Grow a Garden, Steal a Brainrot e Steal an Egg, mas o jogo deve desenvolver identidade própria — especialmente por meio da **caça com laço**, das **criaturas com modificadores** e dos **eventos que transformam o mundo**.

O ciclo principal imaginado é:

**Explorar → capturar criaturas → levá-las à base → gerar ouro/XP passivamente → investir em melhorias → conseguir capturar criaturas mais difíceis.**

A interação entre jogadores e eventos especiais complementa esse ciclo.

## 2. Organização do mundo

- **Ilha Hub:** área compartilhada que reúne jogadores e suas bases individuais. Pode abrigar esteiras de treinamento, lojas, placares e outros elementos de progressão/socialização.
- **Ilha de Caça:** área jogável em que criaturas aparecem ao longo do tempo, variando em espécie, raridade, resistência, tamanho e modificadores. Deve oferecer exploração e encontros entre jogadores.
- **Expansões futuras:** novas ilhas, regiões temáticas ou versões temporárias associadas a eventos. Não são necessárias desde o primeiro protótipo.

## 3. Sistemas principais

### Captura com laço

O jogador usa um **laço** para atingir uma criatura. Quando a captura é iniciada, ocorre um **minigame simples de precisão**, inspirado na lógica de pesca de Stardew Valley: controlar uma área/indicador para manter o alvo sob controle até preencher uma barra de progresso.

- Criaturas mais resistentes tornam o desafio maior.
- A força do jogador e os atributos do laço tornam a captura mais fácil.
- A habilidade do jogador tem alguma importância, mas não deve transformar capturas comuns em tarefas cansativas.
- Devem existir **variações de laços**, com possibilidades como maior poder, alcance, precisão ou estabilidade.
- O minigame precisa funcionar bem no computador e no celular.

A fórmula, os números, o comportamento do alvo e a apresentação visual ainda serão definidos e testados.

### Treinamento passivo

Cada jogador pode usar uma **esteira na Ilha Hub** para acumular força enquanto seu personagem treina automaticamente, sem minigame obrigatório. O ouro pode melhorar a esteira e multiplicadores de ganho, permitindo escalar a progressão. Treinar facilita capturar criaturas mais fortes, mas não substitui explorar e adquirir equipamentos.

### Criaturas e coleção

- As espécies podem ter estilos bem diferentes: fofas, engraçadas, estranhas, grotescas, imponentes, surreais etc. **Não existe um tema visual único obrigatório.**
- Criaturas possuem diferenças relevantes, como raridade, resistência de captura, produção de recursos e aparência.
- Uma mesma espécie pode ter **modificadores/mutações**, tamanhos e características visuais diferentes, permitindo muitas combinações e colecionismo.
- Eventos podem afetar as criaturas e produzir versões especiais.
- Após capturadas, criaturas podem ser instaladas/expostas na base do jogador e **gerar ouro e XP individualmente e de maneira automática**.

A quantidade de espécies, a organização de raridades, as regras de combinação de modificadores e a utilização exata de XP ainda não estão fechadas.

### Economia e melhorias

**O ouro deve ter utilidade recorrente e concreta.** Entre os usos planejados:

- Melhorar a esteira, multiplicadores e a velocidade de treinamento.
- Comprar, desbloquear e aprimorar laços; algumas aquisições podem exigir missões.
- Expandir a base e sua capacidade de acomodar criaturas.
- Investir em outras melhorias de progressão, desde que agreguem valor ao jogo.

Os preços, limites, multiplicadores e demais regras de balanceamento não estão definidos.

### Eventos e atualizações

O jogo deve permitir adicionar conteúdo de modo relativamente simples, reaproveitando espécies, modificadores e sistemas existentes.

Exemplos **conceituais**, não obrigatórios de imediato: eventos sazonais, Admin Abuse (eventos especiais acionados por administradores), invasões, mudanças no clima, mutações temporárias, aparições especiais e bosses mundiais. Um objetivo do design é facilitar combinações entre eventos e modificadores sem recriar todo o jogo a cada atualização.

### Interação entre jogadores

A experiência multiplayer é um pilar do conceito. Possibilidades planejadas incluem:

- Trocas de criaturas.
- Bosses cooperativos, facilitados pela participação de vários jogadores.
- Competições e desafios entre jogadores.
- Exibição de bases, criaturas raras e conquistas no Hub.

Esses recursos **não precisam estar presentes no primeiro protótipo**; serão priorizados conforme o desenvolvimento.

## 4. O que está decidido — e o que continua aberto

**Direção escolhida:** duas funções de ilha (Hub e caça), captura com laço/minigame, treino passivo em esteira, criaturas que produzem recursos, ouro usado em melhorias, variedade de criaturas/modificadores e forte potencial multiplayer/eventos.

**Ainda em aberto:** números da economia; listas de criaturas, laços e raridades; regras exatas de XP; organização das bases; mecânica detalhada de bosses; sistema de trocas; calendário e frequência de eventos; monetização; direção artística definitiva; stack/ferramentas auxiliares e escopo preciso de lançamento.

**Prioridade de design:** começar com algo pequeno e jogável, testar o que é divertido e expandir sem comprometer a estabilidade.

## 5. Como o Codex deve usar este contexto

- **Este arquivo não é uma ordem para implementar o jogo inteiro.** Aguarde pedidos específicos do desenvolvedor.
- Trate as mecânicas descritas como contexto e direção; **não transforme exemplos, sugestões ou possibilidades em requisitos obrigatórios** sem confirmação.
- Ao receber uma tarefa, entenda o que já existe no projeto antes de propor mudanças; dê preferência a soluções pequenas, compreensíveis e fáceis de testar.
- Sugira modularidade e organização quando necessário, sem impor prematuramente uma arquitetura complexa ou nomes fixos de módulos.
- Em funcionalidades multiplayer, considere o servidor como autoridade para ouro, inventário, capturas, compras e progressão; valide dados enviados pelo cliente.
- Explique o que foi criado ou modificado, como testar no Roblox Studio e o que ainda depende de decisão humana. Não afirme que algo foi testado quando não foi.
- A pessoa que está desenvolvendo o jogo decide **a ordem, o ritmo, as ferramentas e o escopo de cada implementação**.

