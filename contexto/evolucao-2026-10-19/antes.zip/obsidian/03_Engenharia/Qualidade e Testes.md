---
tipo: processo
status: proposta
atualizado: 2026-10-17
---

# Qualidade e testes

## Preferência permanente do desenvolvedor — prevalece sobre checklists antigos

O assistente **não deve executar testes pesados por conta própria**, baterias de Play/simuladores, capturas repetidas, benchmarks ou QA extensivo. O desenvolvedor prefere fazê-los manualmente para reduzir gasto de créditos. Fazer apenas revisão de código e verificações leves proporcionais, depois entregar uma lista objetiva com ações e resultados esperados. Só executar testes maiores mediante pedido explícito. Não marcar um caso como validado sem execução; registrar claramente o que ficou para o desenvolvedor.

A matriz abaixo é uma referência para selecionar testes manuais, não uma ordem para o assistente executar toda a matriz. A preferência também está no `AGENTS.md` do workspace.

## Critério de pronto técnico

- A funcionalidade cumpre os critérios de aceite da tarefa e pode ser testada do início ao fim.
- Cliente e servidor têm responsabilidades claras; entrada remota é validada; não há recompensa duplicada por atraso, spam, reentrada ou desconexão.
- Partes, conexões e efeitos temporários são limpos; jogador não fica preso após cancelamento, morte ou teletransporte.
- Não há erros novos no Output do Studio durante o fluxo testado.
- Valores ajustáveis ficam em configuração identificável; mudança de um item não exige alterar sistemas sem relação.
- Os arquivos locais, o lugar salvo e a nota de estado concordam. O diff/commit permite reverter.
- O desenvolvedor recebe instruções curtas de teste e o resultado observado. A experiência permanece **Pronto para playtest** até a validação humana.

## Matriz mínima por tipo de mudança

| Mudança | Verificações |
|---|---|
| HUD/UX | PC em duas resoluções, celular horizontal, áreas seguras, sobreposição, leitura sem tutorial, fluxo com teclado/toque/controle quando aplicável |
| Laço/captura | Acerto/erro, carga mínima/máxima, alcance, alvo movendo, obstáculos, spam, morte/desconexão, duas pessoas mirando a mesma criatura |
| Criaturas | Patrulha perto de bordas, colisão, pausa/reação, lotação, respawn, custo de CPU, consistência entre clientes |
| Economia/base | Compra com saldo insuficiente, duplicação, saída/reentrada, propriedade da base, limites de inventário, reinício do servidor após persistência |
| Mapa/teleporte | Spawn seguro, volta, perda de rede, pontos de chegada, orientação, performance no celular |

## Playtest de diversão

Observar sem instruir primeiro. Anotar: tempo até primeira captura, erros de entendimento, número de tentativas, momentos de empolgação/frustração, satisfação da recompensa e vontade de repetir. Perguntar depois o que a pessoa achou que aconteceria. Registrar evidência em [[Modelo - Playtest]].

## Gates de marco

**M1:** caça compreensível e desejável de repetir. **M2:** progressão útil e dados preservados. **M3:** navegação clara e desempenho aceitável. **M5:** sessão estável com jogadores novos. Os números de meta serão definidos a partir do primeiro conjunto de playtests reais.
