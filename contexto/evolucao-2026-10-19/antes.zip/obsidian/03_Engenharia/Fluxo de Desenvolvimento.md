---
tipo: processo
status: proposta
atualizado: 2026-10-17
---

# Fluxo de desenvolvimento

## 1. Começar com contexto confiável

Ler [[Estado Atual]], a tarefa em [[Backlog]], decisões relacionadas e o código que será alterado. Comparar a cópia local com os scripts do Studio quando a sincronização não estiver ativa. Conferir se o lugar foi salvo. Se houver divergência, resolver e registrar antes de implementar.

## 2. Fatiar pela experiência

Para cada entrega, escrever uma nota curta com: problema observado, resultado desejado para o jogador, escopo da fatia, critérios de aceite, casos de borda e teste de PC/celular/multiplayer. Usar [[Modelo - Funcionalidade]]. Uma fatia deve chegar jogável; uma “refatoração” sem efeito verificável precisa de motivo técnico concreto.

## 3. Implementar e revisar

Criar ramo Git `codex/<assunto>` para trabalho maior; mudanças pequenas podem ficar em um commit isolado. Separar código de servidor, cliente, configuração e apresentação. Registrar decisões novas em uma ADR curta. Rever diff para detectar alterações fora do escopo. Não misturar construção destrutiva do mapa com ajustes de HUD sem cópia do lugar.

## 4. Validar em camadas

Por preferência explícita e permanente do desenvolvedor, o assistente faz apenas revisão e verificações leves. Não iniciar autonomamente baterias de Play, múltiplos dispositivos, benchmarks ou QA extensivo. Entregar checklist de testes manuais com resultado esperado; o desenvolvedor executa e devolve feedback. Testes maiores pelo assistente só mediante pedido explícito. Registrar o que foi efetivamente verificado e o que ficou pendente em [[Qualidade e Testes]].

## 5. Encerrar e aprender

Salvar o lugar, registrar versão/cópia, concluir commit local, atualizar [[Backlog]] e [[Estado Atual]], anexar feedback em nota de playtest. Só marcar **Aprovado** após o desenvolvedor validar a experiência. Feedback negativo vira ajuste específico no mesmo sistema; preservar o motivo da decisão.

## Cadência leve

Uma revisão de prioridades por semana ou após cada playtest, o que vier primeiro. Em cada revisão: escolher 1 objetivo principal, verificar bloqueios, limitar trabalho em andamento e descartar tarefas que perderam valor. A cada marco de [[Roadmap]], revisar diversão, legibilidade, desempenho e arquitetura.

## Sincronização de scripts

Para o estágio atual, **Script Sync** nativo do Roblox Studio é o candidato: liga pastas de scripts ao disco e permite Git, mantendo o mapa no Studio. Antes de ativar, comparar cuidadosamente os dois lados e escolher a versão correta em cada conflito; depois fazer uma alteração pequena de prova e conferir ida/volta. Não configurar duas ferramentas de sync sobre a mesma pasta. Se o projeto passar a exigir que a árvore inteira de objetos seja versionada como arquivos, avaliar Rojo em uma migração própria.

O documento oficial de [Script Sync](https://create.roblox.com/docs/scripting/sync) descreve o diálogo de conflitos e o limite de sincronizar apenas scripts/arquivos suportados. A página de [ferramentas externas](https://create.roblox.com/docs/projects/external-tools) descreve o cenário em que Rojo é mais adequado.
