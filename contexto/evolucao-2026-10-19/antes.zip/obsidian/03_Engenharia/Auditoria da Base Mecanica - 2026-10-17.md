---
tipo: auditoria
status: revisao_de_fontes
data: 2026-10-17
---
# Auditoria da base mecânica — 17/10/2026

> Registro histórico desta rodada. O estado vigente está em [[Estado Atual]]; acessos de upgrades, troca e venda foram revistos em [[Menus Placas e Inventario - 2026-10-18]]. Caminhos locais abaixo podem pertencer ao outro dispositivo.

## Conclusão

A base é **parcialmente modular**. Ajustar o laço e parâmetros da IA já é barato; ampliar coleção, economia e ferramentas ainda exige mudanças em várias camadas. O maior impedimento é a criatura capturada guardar apenas um booleano dourado, sem identidade e características próprias. Capacidades fixas e regras de recompensa duplicadas completam o problema.

Não é necessário recomeçar o jogo. Preservar captura, colisão, feedback e serviço de comportamento; extrair inventário, base, progressão e definições conforme cada entrega os utiliza. Planejamento em [[Plano da Base de Gameplay]].

## Evidência e limites

- Revisão dos fontes locais em C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio e das notas do cofre.
- Consulta ao conector nesta auditoria retornou **nenhum Studio conectado**. Fontes haviam sido sincronizados/conferidos na entrega anterior; alterações posteriores feitas diretamente no Studio não puderam ser verificadas.
- Nenhum Play, simulador, benchmark ou teste de experiência nesta auditoria. Nenhuma mecânica alterada.
- Correção anterior do laço: nove verificações matemáticas passaram naquela entrega, mas contato percebido e diversão continuam pendentes de teste humano.
- Classificação de rigidez é qualitativa: baixa = parâmetros locais; média = componente separado com algumas suposições; alta = regras e representação espalhadas. Não é uma nota de qualidade do jogo.

## Mapa dos sistemas

| Sistema | Existe nos fontes | Rigidez | Consequência / intervenção |
|---|---|---|---|
| Laço e contato | Configuração por ferramenta, mira livre, carga, trajetória, colisão relativa contínua e obstáculos | Baixa para ajuste; média para nova geometria | Velocidade pode mudar isoladamente; volume de captura ainda usa corpo do modelo |
| Disputa | Servidor controla tempo, alvo e ganho | Média–alta | Perfil comum/dourado ainda decide ritmo; separar perfil de captura e efeitos |
| IA | Serviço, perfil e módulo Lumito; passeio, visão, fuga e cansaço | Média | Reutiliza parâmetros; navegação supõe gramado delimitado e modelo específico |
| Espécies/variantes | Construtor Lumito e sorteio dourado | Alta | Não há catálogo de definições completo; raridade/mutação/recompensa confundidas |
| Bolsa/base | Tabelas de sessão; instalação em ordem; três lugares | Alta | Sem IDs/slots explícitos, venda seletiva e troca ficam frágeis |
| Economia/treino | Ouro/XP periódicos e força na esteira | Alta | Regras no bootstrap; benefício da força saturado; sem compras/upgrades |
| HUD/input | Componentes separados, área segura, feedback | Média–alta | Capacidades e seleção de laço fixas; precisa receber dados de itens/slots |
| Persistência | Ausente nos fontes auditados | Não aplicável: falta estrutural | Não há progressão durável; adicionar antes de expandir economia |
| Loja/index/social | Ausentes como sistemas | Não aplicável: novos domínios | Projetar contratos, sem fingir que são apenas novas telas |

## Achados concretos

### Identidade e localização são a primeira dependência

[Bootstrap do servidor, captura](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/HuntACreature.server.luau:142>) insere somente {golden = golden} na bolsa. Instalação retira o primeiro item e usa o tamanho da lista para escolher LugarN, em torno das linhas 171–174. Isso perde espécie, tamanho e mutações e assume ocupação sem lacunas.

**Direção:** instâncias por ID, localização explícita e operações Capture/Install/Sell/Swap que validam propriedade e capacidade. Slots vazios no meio da base deixam de depender do comprimento da lista. Venda e troca precisam ser atômicas dentro do estado do jogador; repetição de pedido não duplica item ou ouro.

### Capacidade não tem fonte única

O servidor limita bolsa/base a três; [HUD](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/client/HUD.luau:324>) formata contagem com /3 e constrói três cartões. Layout da base também depende dos marcadores existentes.

**Direção:** capacidade vem dos atributos calculados do perfil; UI renderiza essa capacidade e a base dispõe de slots compatíveis. Um upgrade não pode só aumentar o número no servidor.

### Dourado acumula responsabilidades

[Construtor e spawn](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/HuntACreature.server.luau:63>) escolhem nome, cor, escala e versão dourada; chance de 18% está no spawn. [CaptureService](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/CaptureService.luau:374>) usa dourado para ritmo e ganho da disputa. Renda/XP e HUD repetem essa distinção.

**Direção:** espécie, raridade, mutação, tamanho, perfil de captura e valores derivados com responsabilidades separadas. Manter migração do comum/dourado atual; não trocar toda a captura de uma vez.

### Ajustar o laço é barato; adicionar consumíveis ainda não

[CaptureConfig](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/shared/CaptureConfig.luau:10>) concentra velocidade padrão de 90 e outros parâmetros. A colisão já está em [LassoCollision](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/LassoCollision.luau>).

[QuickSlot](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/client/QuickSlot.luau>) e [CaptureController](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/client/CaptureController.luau>) foram desenhados para um laço. Poção durante captura exige uma ação de utilidade permitida nesse estado, sem liberar indevidamente outro lançamento. O único RemoteEvent não é problema por si: handlers e contratos devem ser explícitos à medida que crescem.

**Direção:** registro pequeno de itens e handlers por tipo, separando seleção, validação, uso, recarga e efeitos temporários. Não criar um framework genérico para sistemas ainda inexistentes.

### Força e XP ainda não formam progressão completa

[CaptureService, força](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/CaptureService.luau:384>) limita o valor considerado a 15. O bootstrap concede renda a cada cinco segundos e força a cada dois no treino; XP é acumulado sem um ciclo de níveis/utilidade implementado.

**Direção:** centralizar atributos derivados, ganhos e preços; decidir relação força/dificuldade e função do XP. Preservar direção de treino no manequim. Não vender upgrades que aumentem um número sem benefício efetivo.

### IA aproveitável, com limites conhecidos

[CreatureBehaviorService](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/CreatureBehaviorService.luau>) registra comportamento por perfil; [CreatureProfiles](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/CreatureProfiles.luau>) expõe parâmetros. [LumitoBehavior](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/server/LumitoBehavior.luau>) depende do terreno delimitado, partes do modelo e movimentação ancorada.

**Direção:** preservar a IA do Lumito, expor estímulos e efeitos; adaptar navegação/rig quando uma espécie ou área justificar. Não prometer que criaturas voadoras ou terrenos complexos funcionarão só com uma nova linha de configuração.

### Dados de jogador existem apenas durante a sessão

O bootstrap inicializa estado em PlayerAdded e remove em PlayerRemoving. Não foram encontradas integrações DataStore, MemoryStore ou MessagingService nos fontes Luau auditados.

**Direção proposta:** perfil com schemaVersion, IDs estáveis, criaturas/localizações, ouro, força, upgrades, itens, descobertas e cotas de compra quando existirem. Carregamento falho não deve criar e salvar um perfil vazio sobre o anterior. Definir posse da sessão, migração e comportamento de retry. A Roblox recomenda tratar acesso concorrente e dados de jogador cuidadosamente; UpdateAsync ajuda no controle de alterações concorrentes, mas não transforma várias chaves em uma transação. [Boas práticas de Data stores](https://create.roblox.com/docs/cloud-services/data-stores/best-practices) e [dados de jogador e compras](https://create.roblox.com/docs/cloud-services/data-stores/player-data-purchasing).

## Fronteiras propostas, extraídas gradualmente

| Área | Dono do estado/regra | O que não deve saber |
|---|---|---|
| Definições | Espécies, raridades, mutações, itens e curvas | Estado de um jogador específico |
| Perfil | Carregamento, versão, salvamento, posse da sessão | Widgets do HUD |
| Inventário/base | Criaturas por ID, slots e transferências | Fórmulas visuais de cada espécie |
| Economia/progressão | Preços, ouro, atributos e upgrades | Nomes de cartões e botões |
| Captura/IA | Sessão de captura, comportamento e efeitos | Layout da bolsa e persistência direta |
| Loja | Rotação, oferta, limite e resultado de compra | Autoridade fornecida pelo relógio do cliente |
| Cliente | Entrada, apresentação e feedback | Decidir recompensa/posse |

Nomes de módulos e contratos finais serão definidos na entrega correspondente. Evitar duas fontes concorrentes de estado: um serviço muda o perfil; os demais leem os dados publicados.

## Como verificar maleabilidade

- Alterar capacidade por configuração/upgrade atualiza regras e UI.
- Adicionar espécie com comportamento existente não exige branches no HUD, venda e renda.
- Mudar dificuldade/recompensa de uma variante tem um ponto de ajuste.
- Adicionar outro laço usa o mesmo fluxo de seleção/uso.
- Trocar/salvar mantém a mesma identidade e variação.
- Alterar a janela da loja não exige reconstruir sua tela.
- Adicionar comportamento diferente exige módulo específico, sem reescrever economia e inventário.

São critérios para implementações futuras, não resultados já demonstrados.
