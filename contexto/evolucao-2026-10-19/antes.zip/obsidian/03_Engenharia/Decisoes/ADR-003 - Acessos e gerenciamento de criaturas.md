---
tipo: decisao
status: implementada_em_validacao
atualizado: 2026-10-18
---
# ADR-003 — Acessos e gerenciamento de criaturas

## Contexto

Desenvolvedor rejeitou acessos redundantes, troca bolsa/base e ferramentas não possuídas na barra. Solicitou placas clicáveis, menu Criaturas, mercado físico e inventário nativo. Confirmou renda 5×.

## Decisão aplicada

Upgrades nas placas da própria base/treino; Criaturas para Equipar/Desequipar; vender apenas no balcão do hub; Backpack nativo com Tools existentes; renda a cada 1 s mantendo valor do pagamento. Index permanece separado.

## Consequências

Servidor valida acesso físico e posse; UI não é autorização. Equip/Unequip não exigem deslocamento até a base, mas precisam de capacidade livre no destino. Bolsa cheia impede desequipar; troca direta foi removida. Venda elimina exatamente um indivíduo e preserva descoberta. Ordem da hotbar fica a cargo do Roblox, sem persistência personalizada nesta entrega. Preços anteriores permanecem para medir o efeito dos ganhos 5×.

Separação: WorldStations cria acessos; UpgradeBoards desenha placas; CreaturePage gerencia cartões; ToolInventory projeta perfil em Tools; NativeInventory lê seleção. Configuração, regras e apresentação continuam alteráveis isoladamente.

## Status

Decisão do desenvolvedor implementada; UX aguardando playtest. Revisável a qualquer momento. Não reintroduzir caminhos antigos sem registrar nova decisão. Evidência em [[Menus Placas e Inventario - 2026-10-18]].
