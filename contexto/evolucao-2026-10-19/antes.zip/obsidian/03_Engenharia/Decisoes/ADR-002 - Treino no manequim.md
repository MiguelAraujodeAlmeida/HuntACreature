---
tipo: decisao
status: direcao_do_desenvolvedor
data: 2026-10-16
---

# ADR-002 — Treino no manequim

## Contexto

O documento de visão inicial propôs treino passivo em esteira. No feedback posterior, o desenvolvedor substituiu essa direção por um posto em que o avatar laça automaticamente um manequim. O manequim pode ser melhorado com ouro.

## Decisão de produto

O treino final será no **posto de laço com manequim**. Durante o treino, o jogador fica imóvel e não caça nem executa outras ações. A animação é automática; o jogador não precisa lançar manualmente nessa atividade. Uma saída clara encerra animação e ganhos. O ganho e o custo de upgrade serão balanceados posteriormente.

## Consequência

A esteira atual é temporária e não deve orientar arte, UI ou economia futuras. O item de implementação é HAC-06 em [[Backlog]]. A direção artística específica do posto ainda será aprovada.
