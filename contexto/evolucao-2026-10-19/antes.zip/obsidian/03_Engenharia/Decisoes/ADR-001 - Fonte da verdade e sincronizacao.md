---
tipo: decisao
status: proposta
data: 2026-10-16
---

# ADR-001 — Fonte da verdade e sincronização

## Contexto

O protótipo existe no Studio e há cópias locais Luau sem sincronização automática verificada. O repositório Git não possuía commits quando este cofre foi criado; em 2026-10-16 foi feito o primeiro commit `c80c617` da cópia local. A versão do lugar no Studio ainda precisa ser conferida e salva.

## Direção proposta

Usar Git para histórico do código e assets editáveis; usar o cofre para visão, decisões, backlog e testes; salvar versões do lugar no Studio. Configurar Script Sync nativo para os scripts depois de conferir igualdade e resolver conflitos. O código em disco passa a ser a fonte de verdade **somente após** a sincronização ser ativada e testada. Enquanto isso, qualquer mudança precisa ser conferida nos dois lados.

## Motivo

O projeto ainda constrói o mapa no Studio. Script Sync introduz menos mudança de ferramentas agora. Rojo pode ser avaliado quando versionar a árvore completa do lugar trouxer benefício claro.

## Consequências

O mapa/modelos e certas configurações de objetos continuam dependendo de cópia/versionamento do lugar, não apenas do Git. Uma sessão só está encerrada quando código, Studio e [[Estado Atual]] estão coerentes. Reavaliar esta decisão se a sincronização causar conflitos recorrentes ou quando a equipe crescer.

## Status

**Proposta operacional; configuração do Studio pendente.** Não declarar sync ativo sem testá-lo.
