---
tipo: modelo
status: modelo
---

# HAC-XX — Nome da funcionalidade

## Problema observado

O que o jogador tenta fazer? Qual evidência mostra que está ruim?

## Resultado desejado

Como deve se sentir e o que deve conseguir fazer? Descrever em linguagem de jogo.

## Escopo desta fatia

- Incluído:
- Fora desta fatia:
- Dependências:

## Critérios de aceite observáveis

1. 
2. 
3. 

## Contratos e parâmetros

- Estado e autoridade do servidor:
- Entrada/UI/feedback do cliente:
- Configurações de balanceamento:
- Efeitos em outros sistemas:

## Teste

- PC:
- Celular:
- Multiplayer/latência:
- Erro, cancelamento, morte e reentrada:
- Diversão/clareza a observar:

## Resultado e decisão

- Código/objetos alterados:
- Evidências:
- Status: Ideia / Pronto para fazer / Em desenvolvimento / Pronto para playtest / Ajustar / Aprovado
- Próxima ação:
