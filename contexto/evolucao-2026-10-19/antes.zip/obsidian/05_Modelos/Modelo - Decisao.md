---
tipo: modelo
status: modelo
---

# ADR-XXX — Decisão curta

## Contexto

Qual problema ou dúvida reapareceria no futuro?

## Opções consideradas

- Opção A:
- Opção B:

## Decisão e motivo

Qual opção foi escolhida, por quem e com qual evidência?

## Consequências e revisão

O que muda? Qual sinal justificaria revisitar?

## Status

Proposta / aceita / substituída. Link para a decisão que substituiu, se houver.
