---
tipo: modelo
status: modelo
---

# Playtest — AAAA-MM-DD — versão

- Testador / perfil:
- Dispositivo e resolução:
- Versão do lugar / commit:
- Tarefa observada:
- Objetivo do teste:

## Observações sem instrução

| Momento | O que o jogador fez/disse | Resultado visível | Evidência |
|---|---|---|---|
| | | | |

## Métricas simples

- Tempo até primeira captura:
- Tentativas/acertos:
- Erros ou travamentos:
- Quis repetir? Por quê?

## Percepção do jogador

- O que achou que aconteceria?
- O que foi divertido?
- O que frustrou/confundiu?

## Decisão

- Manter / ajustar / descartar:
- Alterações priorizadas:
- Dúvidas abertas:
- Atualizações no [[Backlog]]:
