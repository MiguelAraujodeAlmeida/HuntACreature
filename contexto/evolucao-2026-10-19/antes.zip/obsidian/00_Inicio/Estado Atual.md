---
tipo: estado
status: aguardando_reteste_interacoes
atualizado: 2026-10-18
---
# Estado atual

## Correção mais recente — interações

O desenvolvedor encontrou placas vazias e acessos indisponíveis. [[Correcao de Interacoes - 2026-10-18]] aplicada: descoberta contínua de placas/atributos, frente/verso, eventos de menus independentes e prompts de balcão sem oclusão pelo tampo. Cinco fontes finais conferidos/compilados; 18 verificações isoladas passaram. Nenhum Play novo iniciado. **A correção ainda aguarda reteste humano.** Roteiro completo em [[Checklist das Ultimas Atualizacoes]].

## Base da entrega preservada

[[Menus Placas e Inventario - 2026-10-18]] aplicada ao Studio **[Testing] Hunt a Creature**, placeId **102310424634629**, em Edit. Aguardando teste do desenvolvedor; implementação não significa aprovação de diversão, UX ou persistência.

- Melhorias exclusivamente por botões nas placas da própria base: Base/Bolsa/Velocidade na frente; Manequim/Eficiência e início de treino ao lado do posto. Acessos antigos desativados.
- Botão lateral **Criaturas**: equipar na base ou desequipar para a bolsa. A troca direta entre dois indivíduos foi substituída. Bolsa cheia impede desequipar; não há descarte nem troca implícita.
- Venda de criaturas somente no balcão físico do hub, com seleção e confirmação individual. Servidor exige proximidade mesmo com menu aberto.
- Ouro e XP pagos a cada **1 segundo**, mantendo o valor anterior por pagamento: **renda 5×**, escolha explícita do desenvolvedor. Preços não foram rebalanceados.
- Backpack/hotbar nativos: apenas ferramentas possuídas; consumíveis com quantidade positiva. Reordenação nativa durante a sessão, sem persistência própria da ordem. Index mantém botão próprio.
- Menus com menos guias e acessos duplicados; direção glossy preservada. Som de renda limitado para evitar repetição a cada segundo.

## Base existente preservada

Laço com alcance/carga e contato autoritativo; Lumito com passeio, visão, fuga, cansaço, tamanhos e mutação Dourado; disputa de captura; treino automático imóvel no manequim; isca, armadilha e poção; perfis versionados; cinco categorias de upgrades; loja de ferramentas com rotação global e cota individual persistente. Catálogo e números continuam provisórios.

## Evidência e limites

- Recuperados os **37 fontes** mais recentes do Studio; os 17 locais estavam atrasados. Baseline Git `7b2649a` e cópia em `contexto/retomada-2026-10-18/studio-scripts.json`.
- **42 fontes finais** iguais entre disco/Studio e compilados sem erros; oito placas presentes; nenhum acesso antigo ativo; balcão presente; estrutura temporária de prévia removida.
- Onze verificações leves de regras/inventário passaram. Prévia estática da placa em Edit inspecionada; não valida clique/toque.
- Nenhum Play iniciado pelo assistente, nenhum teste em DataStore real nesta rodada. Checklist manual na entrega vigente.
- O bloqueio antigo de APIs foi resolvido segundo relato humano. Reconexão com progresso, cotas e aprovação do ciclo completo ainda precisam de confirmação específica.
- Cópia de objetos anterior em `ServerStorage.HACBeforeMenus20261018`. Salvamento completo do lugar em disco/nuvem **não confirmado**; backup de scripts e clone interno não substituem um `.rbxl` salvo.

## Próxima ação

Desenvolvedor retestar primeiro as interações corrigidas e depois seguir [[Checklist das Ultimas Atualizacoes]]. Corrigir primeiro bloqueios/perda de progresso; depois clareza e ritmo. Não ampliar catálogo nesta rodada. Texturas finais, teletransporte, mapa maior, modelos/animações finais e configurações seguem adiados.

## Localização e processo

Código: `C:/Users/melg_/OneDrive/Documents/ChatGPT/Hunt A Creature/studio`.
Cofre: `C:/Users/melg_/OneDrive/Documents/Hunt A Creature/Hunt A Creature`.
Não há sincronização automática verificada; comparar antes de sobrescrever. Preferência permanente: verificação leve; Play/QA pesado e agentes auxiliares somente com pedido explícito. Documentos são contexto mutável; feedback posterior prevalece.
