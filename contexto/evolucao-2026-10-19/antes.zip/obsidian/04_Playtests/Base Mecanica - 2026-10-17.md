---
tipo: entrega
status: pronto_para_playtest
data: 2026-10-17
---
# Base mecânica — 17/10/2026

> Registro histórico desta rodada. O estado vigente está em [[Estado Atual]]; acessos de upgrades, troca e venda foram revistos em [[Menus Placas e Inventario - 2026-10-18]]. Caminhos locais abaixo podem pertencer ao outro dispositivo.

Continuação: [[Consolidacao UX e Ferramentas - 2026-10-18]]. Desenvolvedor ainda não testou e autorizou a rodada seguinte; usar o roteiro conjunto dessa nova entrega.

Primeira implementação autorizada do [[Plano da Base de Gameplay]], aplicada ao Studio Edit. **Experiência ainda não aprovada.**

Retomada em 18/10/2026: 31 fontes locais/Studio novamente conferidos e idênticos. Documentação encerrada; nenhuma bateria de testes repetida. Próximo passo é o playtest humano abaixo.

[Guia completo, parâmetros e checklist](<C:/Users/melg_/Documents/ChatGPT/Hunt a Creature/studio/BASE_GAMEPLAY.md>).

## Realizado pelo assistente

- Comparação inicial de 24 fontes locais/Studio e cópia recuperável dos scripts.
- 31 fontes verificados quanto a carregamento/sintaxe em Edit, sem executar os bootstraps.
- 36 verificações de regras com DataStore simulado, incluindo venda repetida, troca cheia, serialização, upgrades, cotas e lease de sessão.
- Cinco verificações pequenas de apresentação em estrutura temporária; nada de bateria de Play/simuladores.
- Comparação final dos 31 fontes sincronizados.

## Roteiro manual

1. Laçar alvo parado/andando/fugindo, lateral e atrás de obstáculo; errar, relançar, soltar; observar pausas/visão.
2. Ouvir efeitos, alternar foco e testar HUD/comandos em desktop/toque. Avaliar agilidade e vontade de repetir.
3. Capturar variantes, instalar indivíduo escolhido, vender da bolsa e da base, trocar com ambas cheias; conferir renda/index.
4. Posicionar isca/armadilha; usar poção na disputa; testar quantidade, recarga, local inválido e cancelamento.
5. Treinar no manequim, sair, morrer/respawnar; comprar cada upgrade e comparar efeito.
6. Comparar loja em dois servidores, esgotar cota individual, verificar virada de rotação.
7. Reconectar com APIs habilitadas e conferir todo o progresso/cota, fora do modo temporário.

## Limites e preparação

DataStore real não foi acessado pelos testes. Studio usa armazenamento separado da produção e requer APIs habilitadas; configuração não foi alterada. Modo temporário só com atributo explícito HACStudioMemoryMode no Workspace, indicado na UI. Nesse modo não há persistência.

Curvas e preços são provisórios. Som utiliza os assets anteriores com mix/comportamento ajustados, sem parecer auditivo. Novo salvamento completo do lugar/publicação não confirmado.

## Feedback humano

Pendente. Registrar passos, resultado observado, resultado esperado e dispositivo. Não preencher “aprovado” por inferência.
