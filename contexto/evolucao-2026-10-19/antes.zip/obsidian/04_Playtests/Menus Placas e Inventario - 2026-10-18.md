---
tipo: entrega
status: aguardando_playtest
atualizado: 2026-10-18
---
# Menus, placas e inventário — 18/10/2026

## Solicitação e resultado

Reduzir redundância, comprar upgrades por placas físicas, gerenciar criaturas em um menu próprio, vender num ponto físico, usar inventário nativo e pagar renda por segundo. Desenvolvedor escolheu **acelerar ganhos em 5×**, não dividir o pagamento anterior.

Aplicado em Edit: oito placas (duas por base), balcão de venda no hub, botões contextuais Equipar/Desequipar, páginas enxutas e hotbar nativa. Ouro/XP pagos por segundo. Placa frontal reúne Base/Bolsa/Velocidade; treino reúne Manequim/Eficiência e Treinar. Compra de ferramentas continua na loja existente.

## Recuperação e reversibilidade

Studio continha 37 fontes atuais; disco tinha 17 antigos. Fontes recuperados antes de editar, baseline Git `7b2649a`. Cópia anterior local e export Studio em `contexto/retomada-2026-10-18/`; notas anteriores em `obsidian-anterior.zip`. Objetos anteriores no Studio em `ServerStorage.HACBeforeMenus20261018`. Nenhum perfil foi migrado/resetado por esta revisão; schema 1 mantido.

42 fontes finais conferidos byte a byte após normalização de quebra de linha da leitura local, compilados em Edit sem executar bootstraps. Backup completo do lugar salvo em disco/nuvem não confirmado. Não confundir cópia interna de objetos com arquivo `.rbxl`.

## Verificações leves observadas

Onze verificações em tabelas/objetos temporários: equipar preserva ID/mutação; desequipar libera slot; Install/Swap legados recusados; bolsa cheia não altera criatura; venda única/descoberta preservada; desequipar após liberar espaço; upgrade isolado; intervalo 1 s/pagamento mantido; validação de perfil; atualização de Tools preserva objetos; quantidade zero remove Tool. Todas passaram; estruturas temporárias removidas.

Uma prévia estática de placa foi inspecionada no Edit. SurfaceGui em PlayerGui com Adornee; ResetOnSpawn falso. Conferência final: oito placas, balcão, nenhum prompt antigo ativo e nenhuma prévia temporária restante.

Nenhum Play iniciado; nenhum teste de input real, multiplayer, DataStore real, benchmark ou emulação de dispositivo. Compilação não garante execução completa nem diversão.

## Checklist do desenvolvedor

1. **Placas:** na própria base comprar cada categoria; valor/benefício atualizam. Saldo insuficiente/nível máximo não descontam. Placa de outro jogador não permite compra. Treinar inicia animação imóvel; Sair restaura movimento.
2. **Criaturas:** equipar/desequipar, inclusive após reabrir painel; ID/tamanho/mutação e renda preservados. Base cheia impede equipar; bolsa cheia impede desequipar. Não deve haver troca direta nem venda nessa tela.
3. **Mercado:** vender um exemplar da bolsa e outro equipado, confirmar preço; ouro entra uma vez e Index permanece. Afastar-se com menu aberto deve impedir venda.
4. **Ferramentas:** abrir mochila nativa com a tecla ` no PC; reordenar; equipar isca/armadilha e usar; quantidade zero desaparece, recompra volta. Durante captura equipar/usar poção sem encerrar a disputa; testar também toque/controle quando disponível.
5. **Renda e progresso:** um Lumito normal tamanho 1 equipado rende 1 ouro e 1 XP por segundo. Sair/reentrar preserva criaturas/localização, ferramentas, saldo e melhorias; ordem da barra não tem persistência própria.

Relatar o primeiro bloqueio ou frustração; não é necessário executar tudo de uma vez. Resultado humano: **pendente**.

## Limites e próximos ajustes

Venda aceita qualquer indivíduo possuído, inclusive equipado, com confirmação. Bolsa cheia exige liberar espaço ou ampliar capacidade antes de desequipar. Mercado usa balcão funcional provisório, sem novo NPC/modelo final. Laço inicial permanece no StarterPack; futuros equipamentos permanentes exigirão integração própria. Novo ritmo econômico precisa de avaliação; preços não foram alterados. Arte/texturas/mapa amplo não fazem parte desta rodada.
