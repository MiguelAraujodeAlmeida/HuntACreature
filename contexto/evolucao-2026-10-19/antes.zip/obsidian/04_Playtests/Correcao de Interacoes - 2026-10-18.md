---
tipo: correcao
status: aguardando_reteste
atualizado: 2026-10-18
---
# Correção de interações — 18/10/2026

## Feedback e diagnóstico

Desenvolvedor reportou placas vazias/não clicáveis e ausência de acesso ao treino, venda e outros sistemas. A entrega anterior falhou no teste humano; compilação/prévia estática não detectaram o problema de inicialização.

Na sessão Play já aberta pelo desenvolvedor, havia placas físicas e atributos, mas nenhuma SurfaceGui de upgrades no PlayerGui. O código fazia descoberta única dos objetos/atributos, sem recuperar chegadas tardias. Essa falha de inicialização é compatível com o estado observado; a ordem exata de replicação no instante de entrada não foi gravada. Prompts de loja/venda estavam habilitados, mas exigiam linha de visão, permitindo que o tampo/objetos ocultassem o aviso.

## Correção aplicada

- UpgradeBoards acompanha a própria base, pasta, peças e atributos a cada 0,2 s; sem espera bloqueante; preserva perfil recebido antes das placas e recria interfaces removidas/reintroduzidas.
- Frente e verso com texto/botões. Distância de ação continua 16 studs; leitura até 40. Abrir menu/treinar/ficar fora do alcance desabilita ação, sem apagar desenho próximo. Outras bases não recebem seus controles personalizados.
- Registro dos eventos de perfil/abertura dos menus precede inicialização independente de placas e inventário. Falha/espera de um componente não impede receber esses eventos.
- Avisos Comprar/Vender clicáveis e sem bloqueio pelo tampo. Proximidade continua validada no servidor; tentativa durante caça/treino dá motivo, sem simplesmente ignorar.
- Treino continua acessível por TREINAR na placa do manequim. Não reativamos o prompt antigo de treino/depósito nem menus duplicados.

## Verificação e limites

Cinco fontes comparados antes da alteração; cinco finais iguais no disco/Studio e compilados. Dezoito verificações isoladas em Edit passaram: raiz ausente, pasta/atributo tardios, perfil anterior, duas faces, botão disponível, não duplicação, comandos simulados, clique repetido, bloqueios, alcance visual, treino, remoção/recriação, mudança de dono e limpeza. Código/evidência em contexto/correcao-interacoes-2026-10-18.

O Play existente foi inspecionado e encerrado para aplicar em Edit. Nenhum novo Play iniciado pelo assistente; testes isolados sem perfil real, compras ou DataStore. Não foi confirmado clique real/toque, ciclo completo ou experiência. Salvamento completo do lugar ainda não confirmado; salvar no Studio antes de encerrar.

## Reteste

[[Checklist das Ultimas Atualizacoes]] é a lista completa, com IDs e resultados esperados. Prioridade: B01–B04 → T01/T04 → V01/V03 → I02 → E01. Falhas novas devem registrar ID, ação, observado, esperado, dispositivo e Output/print. Aguardar parecer humano antes de aprovar a entrega.
