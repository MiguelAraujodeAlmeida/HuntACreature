# Propostas de UX e diversão — 17/10/2026

> **Registro histórico, anterior à IA e ao planejamento atual.** Para prioridade vigente, usar [[Plano da Base de Gameplay]] e as notas [[Combate]], [[Progressao]], [[Criaturas]], [[Jogabilidade]] e [[Interacao]]. O Lumito já se movimenta; upgrades agora integram o planejamento da base. Menções abaixo a criaturas estáticas, adiamento de upgrades e próxima rodada descrevem o estado daquela proposta, não o estado atual. Checklists não autorizam testes pesados pelo assistente.

> Correção posterior do desenvolvedor: variedade de espécies, tamanhos, mutações, comportamentos próprios e upgrades já pertencem ao escopo; não tratá-los como novas ideias. Upgrades de base, treino, bolsa, multiplicador de evolução da força no treino e velocidade estão previstos, mas ainda é cedo para implementá-los. A fatia escolhida foi o comportamento simples do Lumito: passeio, visão, pânico/fuga e cansaço. Entrega e checklist em `../studio/PLAYTEST_LUMITO.md`. Testes extensivos agora são manuais pelo desenvolvedor, conforme `../AGENTS.md`.

Estas são propostas para decidir a próxima implementação, não funcionalidades já entregues. Texturas ficam adiadas por pedido do desenvolvedor.

## Diagnóstico do protótipo

O ciclo técnico existe, mas a caça ainda começa com um alvo estático, passa por uma disputa abstrata na barra e termina em renda periódica. Falta variedade no que o jogador observa, escolhe e executa entre essas etapas. A prioridade proposta é fazer cada encontro produzir uma pequena história, mantendo a rapidez de repetir a ação.

As referências Grow a Garden, Steal a Brainrot e Steal an Egg servem aqui como direção de produto fornecida pelo desenvolvedor: coleção visível, surpresa, evolução perceptível e acontecimentos compartilhados. Não pressupomos reprodução exata de sistemas ou atualização dos jogos de referência.

## Ordem recomendada

| Prioridade | Ideia | Primeira fatia jogável | Por que voltar a jogar | Critério do playtest |
|---|---|---|---|---|
| 1 | Criaturas com personalidade | Lumito passeia, percebe aproximação, avisa e foge por uma curta distância; variante alterna direção em vez de só ganhar velocidade | Cada aproximação exige observação e posicionamento | Sem instrução longa, jogador reconhece alerta e consegue interceptar; sem fuga interminável ou travar em árvores |
| 2 | Captura com resposta física | Criatura inclina/recua, corda tensiona, pequenos trancos sincronizados com a disputa; erro produz reação compreensível | O resultado parece consequência do gesto do jogador | Jogador entende por que ganhou/perdeu e quer tentar de novo; alvo permanece visível no celular |
| 3 | Arremesso caprichado | Bônus pequeno e visível por acertar uma criatura em movimento a distância; começar com uma única condição, validada no servidor | Permite melhorar a habilidade, além dos números | Jogador consegue repetir o feito conscientemente; carga máxima não vira requisito para tudo |
| 4 | Coleção com descobertas | Registro de comum/dourado e duas variações de tamanho/personalidade; primeira captura tem revelação curta e criatura aparece na base | Há uma descoberta concreta para buscar e mostrar | Jogador consegue nomear o próximo objetivo; duplicatas ainda têm utilidade |
| 5 | Upgrades que mudam a ação | Primeiro upgrade escolhe alcance ou recolhimento mais rápido; manequim substitui a esteira conforme direção já definida | Ganho percebido no próximo lançamento, sem depender apenas de multiplicador de renda | Jogador percebe a diferença sem consultar números; treino tem saída clara e não trava o ciclo |
| 6 | Pequenos eventos compartilhados | Uma passagem de Lumitos por uma rota ou uma área de alimento que atrai variantes durante a sessão | Jogadores têm um acontecimento para perseguir juntos | Evento é visível no mundo, dá oportunidade a todos e funciona com poucos jogadores |

## Minha escolha para a próxima rodada

Implementar **um Lumito vivo + reação ao laço**, preservando mapa e economia atuais. Passeio, alerta, fuga curta e reação de captura já permitem avaliar se o núcleo ficou divertido. Separar comportamento num módulo do servidor, definir limites do território e garantir limpeza ao capturar/respawnar. Não expandir para dezenas de espécies antes desse teste.

Depois, acrescentar um único bônus de habilidade e a primeira descoberta de coleção. Coleção/upgrades duradouros exigem persistência antes de oferecer progressão pública; o protótipo atual guarda dados apenas na sessão.

## Ritmo para experimentar, não balanceamento aprovado

- Primeira oportunidade de lançar logo após entrar, com uma criatura acessível e sem paredes de tutorial.
- Encontros comuns curtos o bastante para repetir; dificuldades maiores devem variar o comportamento, não apenas alongar uma barra.
- Após a captura, uma sequência breve: impacto → reação → confirmação → criatura na bolsa/base. Evitar empilhar mensagens e sons no mesmo instante.
- Próximo objetivo visível: uma silhueta de coleção, um upgrade útil ou uma criatura diferente no campo. Evitar transformar a interface em uma lista de tarefas.
- Renda de fundo discreta; descoberta e conquista recebem destaque. Um som sempre alto deixa de distinguir o que importa.

## Som: direção para além da primeira paleta

Já implementado: clique, carga, arremesso, retorno, impacto, marcos de captura e vitória com variação rara. Próxima camada sugerida: vocalização curta por criatura, corda reagindo aos trancos e atmosfera leve por área. Música pode vir depois que esses sons forem legíveis juntos.

Ouvir cinco minutos em fone e celular: o impacto parece ter peso? A vitória rara é distinguível sem olhar? A renda distrai? A repetição da carga cansa? Ajustar timbres, duração e intervalos, não apenas volume.

## Teste de experiência

Pedir a alguém que jogue sem explicação por cinco minutos. Observar tempo até o primeiro lançamento, motivo dos erros, se entende o próximo objetivo e se tenta outra captura espontaneamente. Comparar antes/depois na mesma rota. Esses sinais orientam o próximo ajuste; nenhum efeito isolado garante diversão ou retenção.
