---
tipo: plano
status: implementado_aguardando_playtest
atualizado: 2026-10-18
---
# Plano da base de gameplay

## Direção aprovada

Completar a base mecânica antes de ampliar conteúdo. O plano revisado foi autorizado para implementação; primeira versão aplicada ao Studio Edit. Não confundir entrega técnica com aprovação humana. Ver [[Base Mecanica - 2026-10-17]].

Decisões confirmadas: mesmas ofertas/rotação globais com **cota individual persistente**; **Lumito com tamanhos e mutação Dourado**, sem segunda espécie obrigatória; reaproveitar módulos e extrair apenas domínios necessários.

## Ordem e situação

| Etapa | Resultado solicitado | Situação |
|---|---|---|
| 1 — Caça confiável | Acerto consistente, pausas e laço levemente mais rápido | Laço 100, correção anterior preservada; aguarda reteste humano |
| 2 — Sensação de jogar | Ritmo, comandos, movimentação/câmera, HUD e som | Ritmo/mix/foco/input ajustados; câmera padrão preservada; avaliação humana pendente |
| 3 — Criaturas e dados | ID, espécie, tamanho, mutação, localização, capacidades, persistência | Implementado; serialização e sessão simuladas verificadas, DataStore real pendente |
| 4 — Coleção completa | Equipar/desequipar em Criaturas, vender no mercado, Index | Implementado; operações puras verificadas, UI/Play pendentes |
| 5 — Ferramentas | Uma isca, uma armadilha de chão e uma poção durante captura | Implementado; comportamento e posicionamento aguardam Play |
| 6 — Progressão | Manequim e cinco upgrades com benefício perceptível | Implementado com três melhorias por categoria; economia inicial pendente de balanceamento humano |
| 7 — Loja no hub | Rotação aleatória global, cotas individuais e compras | Implementado; regras simuladas verificadas; teste real em dois servidores pendente |
| 8 — Consolidação | Ciclo completo e maleabilidade confirmados | Integração técnica revisada; aceitação final depende do desenvolvedor |

## Critérios de conclusão

Capturar → reconhecer variação → guardar → equipar/desequipar/vender no mercado → melhorar/treinar → comprar ferramentas → caçar novamente. Esse ciclo deve conservar identidade e progresso, ter comandos claros e oferecer vontade de repetir. Descoberta não some ao vender; cota não repõe ao trocar servidor; equipar/desequipar exige capacidade no destino, sem perda de indivíduo.

HUD, som e controles acompanham todas as entregas. A base só será considerada aprovada após o parecer do desenvolvedor.

## Limites

Mantidos: sete raridades na ordem em [[Criaturas]], estrutura para expansão, coleção persistente e validação no servidor. Removidas como obrigações: segunda espécie, novo modelo de laço, sistema de níveis XP, sprint/dash, bônus perfeito, eventos e PvP completo. Interferência continua hipótese.

Texturas, teletransporte, animação/modelo final e configurações de áudio permanecem adiados. Não adicionar mute nas abas.

## Verificação e próximos ajustes

Verificações leves já realizadas estão em [[Base Mecanica - 2026-10-17]]. Checklist manual cobre caça; áudio/HUD; coleção cheia; ferramentas; treino/upgrades; loja; reconexão. Executar por partes conforme o domínio afetado; não realizar testes pesados automaticamente.

A consolidação pode avançar em entregas específicas autorizadas antes do playtest; ajustes de diversão e balanceamento dependem do parecer dessa versão. Não escalar catálogo, mapa ou sistemas.

## Continuidade vigente — 18/10/2026

[[Menus Placas e Inventario - 2026-10-18]] substitui os antigos acessos de upgrades, venda na bolsa e troca direta. Critérios mais recentes em [[Jogabilidade]] e [[Progressao]]. Assistente conclui revisão leve; desenvolvedor testa e devolve feedback.

Ordem: corrigir bloqueios/perda de progresso → clareza dos acessos e ferramentas → ritmo de caça → economia → reconexão/cotas. Fazer uma alteração principal por feedback, preservando módulos independentes. Sem escalar catálogo antes de avaliar esta base.

### Primeiro roteiro

Capturar Lumito → Criaturas → Equipar → observar ouro/XP por segundo → comprar uma melhoria na placa → visitar mercado e vender uma criatura → conferir Index. Checklist de bordas e ferramentas na entrega vigente.

### Hipóteses de balanceamento

Três Lumitos normais tamanho 1 rendem 3 ouro/s. A primeira melhoria de bolsa custa 25: nove pagamentos (~9 s), sem incluir caça/deslocamento. Isso decorre da aceleração 5× autorizada; não é tempo de progressão aprovado. Um Lumito vende por 12 e uma armadilha custa 12: avaliar utilidade percebida. Loja possui chances/estoque por item, não número fixo de duas ofertas. Laço inicial é o único modelo atual. Nenhum novo preço, laço ou nível de XP foi incluído.
