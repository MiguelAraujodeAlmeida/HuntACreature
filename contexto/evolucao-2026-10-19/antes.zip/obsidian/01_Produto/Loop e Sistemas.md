---
tipo: produto
status: em_validacao
atualizado: 2026-10-18
---
# Loop e sistemas

## Ciclo vigente

Encontrar → escolher abordagem/ferramenta → mirar/carregar/lançar → disputar → reconhecer exemplar → guardar → equipar para renda ou vender no mercado → melhorar/treinar → repetir a caça.

| Sistema | Intenção e implementação atual |
|---|---|
| Laço | Mira exata, carga altera alcance, voo reto com limite/obstáculos, contato no servidor; parâmetros por laço |
| Disputa | Faixa compacta, controle suave, tensão e vitória com efeitos; diversão ainda em validação |
| Criaturas | Lumito com passeio, percepção, fuga/cansaço, tamanhos e Dourado; outras espécies futuras |
| Coleção | Criaturas: equipar/desequipar; Index separado com descobertas permanentes |
| Economia | Equipadas produzem ouro/XP por segundo (5×); venda física; preços provisórios |
| Treino | Avatar imóvel laçando manequim automaticamente; saída explícita e upgrades na placa |
| Ferramentas | Isca, armadilha, poção; inventário nativo somente com itens possuídos |
| Melhorias | Cinco categorias independentes, adquiridas por placas da própria base |
| Loja | Ferramentas no hub, rotação global e cota individual persistente |
| Dados | Perfil versionado; persistência real ainda exige teste específico de reconexão |
| Mundo | Hub e ilha ainda ligados por ponte; teletransporte/mapa final adiados |
| Social/eventos | Hipóteses posteriores, sem implementação desta rodada |

Estado técnico em [[Estado Atual]]; regras por domínio em [[Combate]], [[Progressao]], [[Criaturas]], [[Jogabilidade]] e [[Interacao]]. Registro da entrega atual: [[Menus Placas e Inventario - 2026-10-18]].

## Critério de diversão

Captura comum clara e ágil; rara com maior tensão e recompensa. Evitar tempo sem escolha, erro injusto, notificações que repetem o óbvio e tutorial permanente. Verificar entendimento, controle e vontade de repetir no playtest humano. Cada domínio deve poder mudar sem reescrever todos os outros.
