---
tipo: produto
status: provisoria
atualizado: 2026-10-18
---
# Direção visual e UX

## Referência vigente

Botões glossy com volume, bordas luminosas ciano/dourado, ícones próprios e texto branco arredondado/contornado, conforme imagem do desenvolvedor. A referência posterior supera o pedido antigo de remover todas as caixas. Direção em refinamento, nunca aprovação permanente.

- Fredoka One centralizada em VisualStyle; paleta, ícones e skins compartilhados.
- HUD nas bordas; recursos compactos à esquerda no desktop, carga central inferior apenas ao lançar, disputa compacta.
- Criaturas concentra gerenciamento; Index tem acesso próprio. Inventário de ferramentas usa a UI nativa do Roblox.
- Placas físicas seguem a referência: fundo escuro, nível/benefício legíveis, custo em botão vermelho; início do treino em verde. Sem abrir menu duplicado de melhorias.
- Menus mostram decisão e resultado: estado/renda/preço/capacidade quando necessários. Remover textos que mandam jogar ou repetem ações visíveis.
- Animações de foco/pressão/retorno e feedback de ação; manter área de input estável. Não multiplicar efeitos/sons a ponto de impedir leitura. Renda por segundo não exige som por segundo.
- Considerar área segura e toque. Sem tutorial permanente, título fixo do jogo ou mute em cada painel; configurações futuras.
- Mundo de brinquedo modular, saturado e coerente; texturas atuais são amostras, refinamento adiado. Silhuetas/expressões das criaturas devem continuar legíveis.

## Aceite

Polir uma amostra e receber feedback antes de escalar produção. Não confundir compilação ou prévia estática com aprovação estética, auditiva ou de interação. [[Menus Placas e Inventario - 2026-10-18]] inclui o checklist atual. Valores técnicos em `studio/STYLE_GUIDE.md` e `studio/shared/VisualStyle.luau`.
