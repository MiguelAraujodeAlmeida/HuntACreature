---
tipo: escopo
status: hipotese
atualizado: 2026-10-17
---
# Interação

## Intenção registrada

O desenvolvedor considera que **talvez** seja interessante um jogador atrapalhar outro durante a captura, com referências a Roube um Brainrot e Steal an Egg. Isso é uma hipótese para experimentar, não autorização para roubo permanente, PvP completo ou perda de criaturas já possuídas.

Hoje existe exclusividade de captura via BusyUserId; não há sistema de interferência.

## Proposta de primeira experiência

Depois de estabilizar o ciclo individual, testar uma interferência curta e visível em área de caça, com defesa ou possibilidade de esquiva. Sugestão: ferramenta provoca distração breve, com aviso e recarga; não transfere automaticamente a propriedade do alvo.

Definir antes de codificar: quem pode afetar quem, alcance, duração, custo, janela de defesa e limite por captura. Manter dono da captura e concessão da recompensa sob autoridade do servidor. Efeito não pode deixar IA ou sessão travada.

## Limites propostos para o experimento

- Hub e treino sem interferência.
- Limite de frequência e proteção contra vários jogadores bloquearem uma pessoa continuamente.
- Resultado compreensível para atacante e caçador; captura ainda pode ser vencida.
- Sem remoção de criaturas já guardadas, saldo ou upgrades.
- Recurso desativável por configuração, sem depender dele para fechar o ciclo básico.

Esses limites são sugestões de design, não decisões já aprovadas. A validação exige dois jogadores controlados pelo desenvolvedor; o assistente não inicia teste multiplayer autônomo.

## Decisão de passagem

Ao concluir a base individual, escolher entre experimentar uma única interação ou adiar com motivo registrado. Se gerar mais frustração que escolha interessante, ajustar ou descartar. Não bloquear todos os outros sistemas por uma hipótese social.

Alternativas futuras, fora da base obrigatória: comparar coleções, visitar bases e caças cooperativas. Não iniciar trocas entre jogadores, mercado ou roubo de propriedade sem novo escopo.
