---
tipo: escopo
status: aguardando_playtest
atualizado: 2026-10-18
---
# Jogabilidade

## Direção

Movimentação agradável, captura dinâmica, clareza e recompensa; polir o núcleo antes de ampliar conteúdo. Encontrar → capturar → reconhecer indivíduo → guardar → equipar para renda ou vender no mercado → melhorar/treinar → caçar novamente.

## Criaturas

O botão lateral **Criaturas** concentra o gerenciamento. Cartão mostra nome, raridade/tamanho, estado e renda por segundo. Uma ação contextual: **Equipar** (bolsa → base) ou **Desequipar** (base → bolsa). Filtros Todas/Equipadas/Na bolsa.

Decisão posterior substitui a antiga troca de dois indivíduos. Equipar exige vaga na base; desequipar exige vaga na bolsa. Com ambas cheias, liberar espaço vendendo no mercado ou ampliando capacidade. Sem troca implícita, perda de características ou descarte automático. Gerenciamento não exige visitar a base; caça/treino bloqueiam a operação.

Venda ocorre somente no balcão físico do hub, por indivíduo, com valor e confirmação contextual. Pode vender exemplar da bolsa ou equipado; produção/ocupação devem atualizar. Não há botão de venda em Criaturas.

## Inventário de ferramentas e Index

Barra e mochila nativas do Roblox, com apenas ferramentas possuídas e quantidades reais. Jogador pode reorganizar a barra pela mochila; nenhuma tecla numérica fixa identifica isca/armadilha/poção. A ordem não é persistida pelo jogo entre sessões. O laço inicial é permanente; consumível zero desaparece.

Index tem botão próprio e atalho I, filtro de raridade/paginação e ficha. Descobertas sobrevivem à venda. Inventário atual não equivale a catálogo descoberto. Registro detalhado de variantes, recordes e prêmios por descoberta são possibilidades futuras.

## Aceite humano

Um ciclo completo sem item perdido/duplicado, controles presos ou explicação externa para uma ação básica. Avaliar clareza, sensação de controle, duração percebida e vontade de repetir. Desktop/toque/controle e uso de poção durante disputa aguardam teste manual. Entrega atual: [[Menus Placas e Inventario - 2026-10-18]].

Melhorias de câmera, sprint/dash, bônus de descoberta e novos efeitos não são tarefas automaticamente aprovadas. Configurações de áudio continuam futuras, sem mute repetido nos painéis.
