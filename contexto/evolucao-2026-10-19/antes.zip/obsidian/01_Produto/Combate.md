---
tipo: escopo
status: pronto_para_playtest
atualizado: 2026-10-18
---
# Combate

Requisitos e implementação do [[Plano da Base de Gameplay]]. Entrega: [[Base Mecanica - 2026-10-17]]. Experiência ainda não aprovada.

## Escopo confirmado

Laço levemente mais rápido, armadilhas no chão, iscas para atrair criaturas e poções durante a captura. O combate deve ser dinâmico, legível e satisfatório.

## Implementação atual

- Laço padrão: **100 studs/s**, preservando alcance e carga. Colisão contínua com alvo móvel e bloqueio por obstáculos da entrega anterior mantidos.
- Disputa: tempo máximo inicial de 22 s; ganho comum 0,29/s antes dos modificadores. Dificuldade deriva do exemplar; força tem benefício decrescente, sem corte abrupto em 15.
- Isca: atrai Lumitos tranquilos por 15 s, com raio de 18 studs e recarga de 8 s. Perigo continua tendo prioridade.
- Armadilha: posicionável em chão livre da ilha, arma em 1 s, dura até 25 s e desacelera um alvo a 35% por 6 s; recarga de 10 s.
- Poção: utilizável durante a disputa, reduz ritmo do alvo a 65% por 6 s; recarga de 12 s.
- Controles de seleção no teclado/toque/controle, saída explícita da disputa e cancelamento do comando ao perder foco. Space/A durante a disputa não também provoca salto.
- Som de carga sem disparos repetitivos; mix de acerto, progresso e renda ajustado.

São valores provisórios em GameplayConfig/CaptureConfig, não balanceamento aprovado. Usam os assets sonoros anteriores; qualidade auditiva permanece pendente.

## Regras

Servidor valida estado, posse, quantidade, distância e posicionamento antes do consumo. Ferramentas no mundo não atravessam obstáculos ou saem da área de caça. Poção não libera outro lançamento durante a disputa. Laço básico continua suficiente para o Lumito. Novos tipos/modelos de laço não são requisito desta entrega.

## Aceite manual

- Acertos frontais/laterais e contra fuga iniciam uma única disputa; obstáculos bloqueiam.
- Erros têm recuperação clara; iniciar/soltar/terminar não prende comandos ou IA.
- Ferramentas têm função perceptível; uso inválido não consome; quantidade e recarga estão claras.
- Poção funciona durante a disputa e seu efeito termina.
- Julgar ritmo, resposta e satisfação sonora. Assistente não executa bateria de Play por conta própria.

## Ideias fora da entrega

Bônus de execução perfeita e novos desafios do minigame continuam sugestões, não obrigações. Polimento final de animação/modelo e texturas segue adiado.
